#!/usr/bin/env bash
# 启动 Kaspa 挖矿。用法：
#   ./start.sh          单实例，挖到 config.sh 的 ACTIVE_WALLET
#   ./start.sh --dual   双实例：卡组1 -> 钱包1，卡组2（GPUS_2） -> 钱包2
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

DUAL=0
[ "${1:-}" = "--dual" ] && DUAL=1

mkdir -p "$LOG_DIR"

launch() {  # $1 钱包编号  $2 显卡  $3 API端口  $4 会话名
    local w="$1" g="$2" api="$3" sess="$4"
    SCREEN_LS="$(screen -ls 2>/dev/null || true)"
    if echo "$SCREEN_LS" | grep -q "\.${sess}[[:space:]]"; then
        echo "[=] 会话 ${sess} 已在运行，跳过（先 ./stop.sh 再启动）"
        return 0
    fi
    screen -dmS "$sess" bash "$PACK_DIR/run_instance.sh" "$w" "$g" "$api" "$sess"
    echo "[+] 已启动会话 ${sess}：钱包${w} / 显卡 ${g} / API :${api}"
}

if [ "$DUAL" = "1" ]; then
    [ -n "$GPUS_2" ] || { echo "[!] --dual 需要 config.sh 里的 GPUS_2 非空"; exit 1; }
    launch 1 "$GPUS"   "$API_PORT"   kaspa-miner
    launch 2 "$GPUS_2" "$API_PORT_2" kaspa-miner2
else
    launch "$ACTIVE_WALLET" "$GPUS" "$API_PORT" kaspa-miner
fi

# 启动后等待最多 10s，直到看到 lolMiner 进程；否则启动失败，打日志并退非零
DEADLINE=$(( $(date +%s) + 10 ))
while [ "$(date +%s)" -lt "$DEADLINE" ]; do
    if pgrep -f "lolMiner" >/dev/null 2>&1; then break; fi
    sleep 0.5
done

sleep 3
echo ""
echo "[*] screen 会话："
screen -ls 2>/dev/null | grep -E "kaspa-miner" || true
if ! pgrep -f "lolMiner" >/dev/null 2>&1; then
    echo "[!] 未检测到 lolMiner 进程，启动可能失败；查看：screen -r kaspa-miner  或 $LOG_DIR"
    exit 1
fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo 127.0.0.1)"
echo ""
echo "[*] 实时输出  ：screen -r kaspa-miner"
echo "[*] 状态面板  ：http://${IP}:${API_PORT}/gui"
echo "[*] 矿池收益  ：https://woolypooly.com 搜你的 kaspa: 钱包地址"
echo "[*] 日志目录  ：$LOG_DIR"
if [ "$DUAL" = "1" ]; then
    echo "[*] 双实例已开启：钱包1=$KASPA_WALLET_1 钱包2=$KASPA_WALLET_2"
fi
exit 0
