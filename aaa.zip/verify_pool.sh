#!/usr/bin/env bash
# 探测 woolypooly Kaspa stratum 端口：TCP 连通 + 发 mining.subscribe 看握手回应
# 用法：./verify_pool.sh [host] [port1 port2 ...]
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

HOST="${1:-kaspa.woolypooly.com}"
PORTS="${2:-3333 3334 3335 5555 7777 3344}"

probe() {
    local host="$1" port="$2"
    python3 - "$host" "$port" <<'PY'
import socket, sys, json, time
host, port = sys.argv[1], int(sys.argv[2])
t0 = time.time()
try:
    s = socket.create_connection((host, port), timeout=6)
except Exception as e:
    print(f"  :{port}  TCP 失败：{e}"); sys.exit(2)
try:
    s.settimeout(6)
    msg = {"id": 1, "method": "mining.subscribe", "params": ["kaspa-probe/1.0"]}
    s.sendall((json.dumps(msg) + "\n").encode())
    data = s.recv(4096)
except Exception as e:
    print(f"  :{port}  TCP 通 ({int((time.time()-t0)*1000)}ms)，但 stratum 无回应：{e}"); sys.exit(1)
finally:
    s.close()
rtt = int((time.time() - t0) * 1000)
text = data.decode(errors="replace").strip()
first = text.splitlines()[0] if text else "(空)"
print(f"  :{port}  OK  RTT={rtt}ms  响应：{first[:120]}")
PY
}

echo "[*] 探测 ${HOST}（来自 config 的候选端口：${PORTS}）"
GOOD=()
for p in $PORTS; do
    if out="$(probe "$HOST" "$p")"; then
        echo "$out"
        GOOD+=("$p")
    else
        echo "$out"
    fi
done

echo ""
if [ "${#GOOD[@]}" -eq 0 ]; then
    echo "[!] 没有可用 stratum 端口（当前网络可能不通，或端口列表不准）。"
    echo "    矿机启动不受影响，确认后把 config.sh 的 POOL_PRIMARY 改成可用端口即可。"
else
    echo "[OK] 可用端口：${GOOD[*]}"
    echo "    当前 POOL_PRIMARY=$POOL_PRIMARY"
    BEST="${GOOD[0]}"
    if [ "$POOL_PRIMARY" != "stratum+tcp://${HOST}:${BEST}" ]; then
        echo "    建议：把 config.sh 的 POOL_PRIMARY 改为 stratum+tcp://${HOST}:${BEST}"
    fi
fi
