#!/usr/bin/env bash
# tune.sh - 云机端 host/GPU/内存 调优 (root 运行, 幂等, 可反复跑)
# 目标: 榨干 GPU (锁频/超频/ECC/MIG/温控) + 榨干可用内存 (DAG 生成缓冲/页面/缓存策略)
set -uo pipefail

step() { printf '\n== %s ==\n' "$*"; }

# ---- 1. 纪元 / DAG / 内存预算 ----
step "纪元 / DAG / 内存预算"
# 优先级: 1) t-rex 日志真实 epoch  2) 时间估算 (30000 块/纪元, ~13s/块)
NOW_TS="$(date +%s)"
LOG_EPOCH=$(grep -aoiE 'epoch[ (:]*[0-9]+' "$PWD/logs/t-rex.log" 2>/dev/null | tail -n1 | grep -oE '[0-9]+$')
if [ -n "${LOG_EPOCH:-}" ]; then
  EPOCH="$LOG_EPOCH"; SRC="log"
else
  EPOCH=$(( (NOW_TS - 1438269973) / 390000 + 1 )); SRC="estimate"
fi
DAG_BYTES=$(( 1073741824 + 8388608 * EPOCH ))
DAG_GB=$(awk -v b="$DAG_BYTES" 'BEGIN{printf "%.2f", b/1073741824}')
RAM_GB=$(awk '/MemTotal/{printf "%.1f",$2/1048576}' /proc/meminfo 2>/dev/null)
AVAIL_GB=$(awk '/MemAvailable/{printf "%.1f",$2/1048576}' /proc/meminfo 2>/dev/null)
RAM_GB="${RAM_GB:-?}"; AVAIL_GB="${AVAIL_GB:-?}"
MIN_NEED=$(awk -v b="$DAG_BYTES" 'BEGIN{printf "%.1f", 4*b/1073741824}')
echo "epoch ~ $EPOCH ($SRC)   DAG ~ ${DAG_GB} GiB   (构建缓冲2x + 预生成下一纪元1x + 系统1x)"
echo "MemTotal=${RAM_GB} GiB   MemAvailable=${AVAIL_GB} GiB   建议 >= ${MIN_NEED} GiB"
awk -v a="$RAM_GB" -v m="$MIN_NEED" 'BEGIN{exit !(a<m)}' 2>/dev/null \
  && echo "[warn] 内存偏紧: 调低 INTENSITY, 或 DAG_EPOCH 置空, 或加 RAM 再挖" || true

# ---- 2. 内存 / CPU 策略 ----
step "内存 / CPU 策略"
if swapoff -a 2>/dev/null; then echo "swapoff ok"; else echo "swapoff 跳过(已是 no-swap 或无权限)"; fi
echo 1 > /proc/sys/vm/swappiness 2>/dev/null || echo "swappiness 跳过"
echo always > /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null || echo "THP 跳过"
echo 2000000 > /proc/sys/vm/min_free_kbytes 2>/dev/null || true
for CPUF in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  [ -w "$CPUF" ] && echo performance > "$CPUF" 2>/dev/null
done
free -h
echo "策略: swappiness=1, THP=always, min_free_kbytes=2GiB, governor=performance"

# ---- 3. GPU 榨干 ----
step "nvidia-smi 信息"
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "无 nvidia-smi, 跳过驱动层"
else
  nvidia-smi --query-gpu=index,name,pstate,temperature.gpu,power.draw,power.limit,memory.total,memory.used,utilization.gpu,clocks.sm,clocks.mem \
    --format=csv,noheader,nounits | awk -F', *' '{
      printf "GPU%s %s p%s %sC %s/%sW MEM %s/%sMiB UTIL %s%% SM %sMHz MEM %sMHz\n",$1,$2,$3,$4,$5,$6,$8,$7,$9,$10,$11
    }'

  step "Persistence / ECC / MIG"
  nvidia-smi -pm 1 >/dev/null 2>&1 && echo "pm=1 ok" || echo "pm 失败"
  if [ "${ECC_OFF:-0}" = "1" ]; then
    nvidia-smi -e 0 >/dev/null 2>&1 && echo "ECC off 已发令 (重启生效)" || echo "ECC off 被拒"
  else
    echo "ECC 保持 (要关: ECC_OFF=1 $0)"
  fi
  nvidia-smi -mig 0 >/dev/null 2>&1 && echo "MIG off ok" || echo "MIG off 跳过(不支持或已关)"

  step "功耗 / 锁频"
  if [ "${PL_WATT:-0}" != "0" ] && nvidia-smi -pl "$PL_WATT" >/dev/null 2>&1; then
    echo "power-limit -> ${PL_WATT}W ok"
  else
    echo "power-limit 跳过 (未设 PL_WATT 或厂商封顶; 兜底用 start.sh 的 POWER_LIMIT)"
  fi
  if [ -n "${LOCK_CORE:-}" ]; then
    nvidia-smi -lgc "$LOCK_CORE" >/dev/null 2>&1 && echo "lock core -> $LOCK_CORE ok" \
      || echo "lock core 被拒 -> 改用 start.sh 的 LOCK_CCLOCK(由 T-Rex 锁)"
  else
    echo "LOCK_CORE 未设, 跳过 (形如 LOCK_CORE=1500,1500)"
  fi
  if [ -n "${CLOCK_TWEAK:-}" ]; then
    nvidia-smi -ac "$CLOCK_TWEAK" >/dev/null 2>&1 && echo "clock tweak -> $CLOCK_TWEAK ok" \
      || echo "clock tweak 被拒 (云卡常封顶; 兜底用 start.sh 的 CORE_OFFSET/MEM_OFFSET)"
  else
    echo "CLOCK_TWEAK 未设, 跳过 (形如 CLOCK_TWEAK=10401,2400)"
  fi
fi

step "完成"
echo "回卷: /proc/sys 改动重启失效; -pm/-lgc 保持至驱动重启; ECC 关掉后如需回退: nvidia-smi -e 1 并重启"
