#!/usr/bin/env bash
set -uo pipefail
# Run on the Mac. Cloud miner then connects to 127.0.0.1:1010.
# 断线自动重连; 装了 autossh 就走 autossh。
MINER_HOST="${MINER_HOST:-8.155.86.169}"
MINER_PORT="${MINER_PORT:-53205}"
POOL_HOST="${POOL_HOST:-141.95.124.89}"
POOL_PORT="${POOL_PORT:-1010}"

ssh_common=(
  -o ServerAliveInterval=30
  -o ServerAliveCountMax=3
  -o ExitOnForwardFailure=yes
  -o ConnectTimeout=10
)

if command -v autossh >/dev/null 2>&1; then
  export AUTOSSH_GATETIME=0
  exec autossh -M 0 -N "${ssh_common[@]}" \
    -R "127.0.0.1:${POOL_PORT}:${POOL_HOST}:${POOL_PORT}" \
    -p "$MINER_PORT" "root@${MINER_HOST}"
fi

# 无 autossh: 自杀式重连循环
while true; do
  echo "$(date '+%F %T') relay: connecting root@${MINER_HOST}:${MINER_PORT}" >&2
  ssh -N "${ssh_common[@]}" \
    -R "127.0.0.1:${POOL_PORT}:${POOL_HOST}:${POOL_PORT}" \
    -p "$MINER_PORT" "root@${MINER_HOST}"
  echo "$(date '+%F %T') relay: ssh exited ($?), 5s 后重连" >&2
  sleep 5
done
