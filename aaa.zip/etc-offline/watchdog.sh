#!/usr/bin/env bash
# watchdog.sh - 外部看护闭环 (替代 t-rex 内置 watchdog)
# 轮询 t-rex HTTP API (/summary): 进程死亡 / 算力掉线 / 连续无响应 -> 重启 start.sh
# 用法: nohup ./watchdog.sh >/dev/null 2>&1 &   (或交给 miner.service)
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

API_HOST="${API_HOST:-127.0.0.1}"
API_PORT="${API_PORT:-4067}"
INTERVAL="${INTERVAL:-60}"        # 检查周期秒
MIN_MHS="${MIN_MHS:-0}"           # 全机算力下限 (MH/s); 0=关闭该检查
STRIKES="${STRIKES:-3}"           # 连续几次掉线才重启
COOLDOWN="${COOLDOWN:-20}"        # 重启前等待
LOG="$ROOT/logs/watchdog.log"
mkdir -p "$ROOT/logs"

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
logsize_guard() {
  [ -f "$LOG" ] || return 0
  local sz; sz=$(stat -c%s "$LOG" 2>/dev/null || stat -f%z "$LOG" 2>/dev/null || echo 0)
  [ "$sz" -gt 33554432 ] && : > "$LOG"
}

start_miner() {
  log "starting start.sh"
  setsid ./start.sh >> "$ROOT/logs/t-rex.out" 2>&1 &
}

stop_miner() {
  pkill -f "bin/t-rex" >/dev/null 2>&1
  for _ in 1 2 3 4 5 6 7 8 9 10; do
    pgrep -f "bin/t-rex" >/dev/null 2>&1 || return 0
    sleep 1
  done
  pkill -9 -f "bin/t-rex" >/dev/null 2>&1
}

summary_json() {
  curl -fs --max-time 6 "http://$API_HOST:$API_PORT/summary" 2>/dev/null || true
}

# 取总算力 (兼容 hashrate / hash_rate 两种键)
rate() {
  summary_json | grep -oE '"(hashrate|hash_rate)": ?"?[0-9.]+' | head -n1 | grep -oE '[0-9.]+$'
}

strike=0
log "watchdog up (interval=${INTERVAL}s min=${MIN_MHS:-off}MH/s strikes=$STRIKES)"

while true; do
  logsize_guard
  if ! pgrep -f "bin/t-rex" >/dev/null 2>&1; then
    log "t-rex 不存在 -> 重启"
    sleep "$COOLDOWN"; start_miner; strike=0; sleep "$INTERVAL"; continue
  fi

  j=$(summary_json)
  if [ -z "$j" ]; then
    strike=$((strike+1)); log "API 无响应 (strike $strike/$STRIKES)"
  else
    h=$(rate)
    if [ "${MIN_MHS:-0}" != "0" ] && [ -n "$h" ]; then
      if awk -v h="$h" -v m="$MIN_MHS" 'BEGIN{exit !(h+0 < m+0)}'; then
        strike=$((strike+1)); log "算力 ${h} MH/s < ${MIN_MHS} (strike $strike/$STRIKES)"
      else
        strike=0
      fi
    else
      strike=0
    fi
  fi

  if [ "$strike" -ge "$STRIKES" ]; then
    log "重启: strike 达标"
    stop_miner; sleep "$COOLDOWN"; start_miner; strike=0
  fi
  sleep "$INTERVAL"
done
