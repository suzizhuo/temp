# Kaspa 满血挖矿脚本包（Linux / woolypooly / lolMiner）

按 `../方案.MD` 实现的完整执行包。目标：Linux + NVIDIA 机器满血挖 Kaspa（kHeavyHash），
算力直打你的钱包；两个钱包地址均已内置并通过校验，可随时切换或双开。

## 0. 内置信息（已填好，直接用）

| 项 | 值 |
|---|---|
| 钱包1（默认） | `kaspa:qqrwgt0kpe7c58y90plagddqpsky9046eh88epf0t2zsje3z4vxg7hfrgqh4m` |
| 钱包2 | `kaspa:qrhgpcrt303kaz3pvsz3ulm95lrjet6jp956e2qrmhe5tqna3ezh5hrtklcqn` |
| 矿池 | `stratum+tcp://kaspa.woolypooly.com:3333`（含备池故障切换） |
| 算法 | `KASPA`（kHeavyHash） |
| 矿机 | lolMiner `1.98a` Linux 64位，sha256 已锁定 |
| 矿工名 | `linux-rig-01`（改 config.sh 里的 `WORKER`） |

两个地址均通过 rusty-kaspa 官方算法逐位校验（version=0 / 32 字节 payload / 校验和 OK）。
随时可复验：`./wallet_tool.sh verify`

## 1. 文件清单

```
config.sh            钱包/矿池/超频/稳定性配置（核心）
install_deps.sh      装依赖 + 驱动检查
download_miner.sh    下载 lolMiner（sha256 校验）
oc_tune.sh           NVIDIA 满血调优（持久模式/功耗墙/锁频/显存预设）+ 系统内存调优（自动调用 mem_tune.sh）
mem_tune.sh          系统内存满血调优（2.5GiB 大页 / swappiness / THP / 可选 swapoff），由 oc_tune.sh 调用
start.sh             启动挖矿（screen 后台；--dual 双实例双钱包）
stop.sh              停止
status.sh            状态/算力/份额
monitor.sh           实时监控（5s 刷新）
run_instance.sh      单实例参数组装 + 崩溃守护循环（start.sh 内部调用）
verify_pool.sh       矿池端口探测（TCP + stratum 握手）
wallet_tool.sh       钱包校验 / 切换默认钱包
emergency.sh         watchdog script 模式钩子
systemd_install.sh   开机自启（与 screen 二选一）
```

## 2. 满血激活三步

```bash
# 步骤 0：上传本目录到 Linux 机器，进入后给执行权限
cd kaspa-miner-pack && chmod +x *.sh

# 步骤 1：装依赖 + 下矿机（自动校验 sha256）
sudo ./install_deps.sh
./download_miner.sh

# 步骤 2：满血调优 + 启动
sudo ./oc_tune.sh          # 持久模式 + 每卡最高核心/显存 clock 对（-ac，榨 GPU）+ 系统内存大页调优；
                           #   省电预设：改 config.sh MEM_CLOCK_LOCK="810" 后再跑 ./oc_tune.sh
./start.sh                 # 默认挖到钱包1
```

验证是否真的在挖：

```bash
./status.sh                # 看 Total Speed / Accepted
./monitor.sh               # 实时
# 或浏览器打开 http://<矿机IP>:4066/gui
```

收益核对：https://woolypooly.com → 搜你的 `kaspa:` 地址，里面看实时算力、已接受份额、未结算量。

## 3. 关键设计（都按官方文档来）

- **矿机与版本**：lolMiner 1.98a（GitHub Releases，sha256 `0b807829…f270` 已锁定，
  不一致会拒绝运行）。`--algo KASPA` 即 kHeavyHash。
- **故障切换**：lolMiner 支持多组 `--pool/--user`（官方 wiki：主池短时间掉线 5 次切下一组），
  config.sh 的 `POOL_BACKUPS` 已内置同主机备端口。
- **满血关键参数**：
  - `--mclk 810`：lolMiner 官方文档对 KASPA/ALPH 的预设——kHeavyHash 吃矩阵算力、
    显存带宽压力小，锁 810MHz 后功耗暴降而算力几乎不掉（要榨显存带宽改 `MEM_CLOCK_LOCK="*"`）；
  - `--cclk`：核心锁频（文档注明 Ampere/Turing 生效；Pascal 用 `oc_tune.sh` 的 `nvidia-smi -lgc`）；
  - `--pl` 功耗墙、`--fan` 风扇；
  - `--watchdog exit` + `run_instance.sh` 守护循环：矿机崩溃退出码 42 自动拉起；
  - `--tstop/--tstart` 温度保护（默认关闭，24/7 建议填，例 83/70）；
  - `--apiport` 网页统计面板 `/gui`；
  - `--statsformat` 统计项自定义。
- **双钱包两种用法**：
  1. 切换默认钱包：`./wallet_tool.sh switch 2` 然后 `./stop.sh && ./start.sh`
  2. 同一台机两张卡组分打两个钱包：改 config.sh 的 `GPUS_2`，然后 `./start.sh --dual`
     （实例1 → 钱包1 用 `GPUS`，实例2 → 钱包2 用 `GPUS_2`，API 端口自动错开）

## 4. 端口说明

`stratum+tcp://kaspa.woolypooly.com:3333` 为 woolypooly Kaspa 常用端口；
**本次打包环境无法直连 woolypooly 官网核实端口**，所以：

- `POOL_PRIMARY` 默认 3333，`POOL_BACKUPS` 内置 3334/3335；
- 先跑 `./verify_pool.sh` 自动探测（TCP + 发 `mining.subscribe` 看握手），
  把可用端口填回 config.sh 即可；探测不通只是当前网络问题，不影响本机矿机运行。

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| `未检测到 nvidia-smi` | 装驱动：`sudo apt install -y nvidia-driver-535 && sudo reboot` |
| 启动几秒后日志报 pool connect failed | 跑 `./verify_pool.sh` 换端口；防火墙放行外网 TCP 3333 |
| 算力为 0 或 Mh/s 极低 | `oc_tune.sh` 没跑：显存/核心频率没锁；确认 `nvidia-smi` 里 clocks 已变化 |
| 功耗高想降温 | `MEM_CLOCK_LOCK` 已是 810；再降 `POWER_LIMIT`；核心可适当降频 |
| 想开机自启 | `sudo ./systemd_install.sh`（用了它就别再开 screen） |
| 切到钱包2 | `./wallet_tool.sh switch 2 && ./stop.sh && ./start.sh` |
| 地址抄错 | `./wallet_tool.sh verify` 会直接报 CHECKSUM FAIL |

## 6. 卸载

```bash
./stop.sh
sudo ./oc_tune.sh reset      # 清锁频（可选）
# 若装过 systemd：sudo ./systemd_install.sh 卸载命令见其输出
rm -rf kaspa-miner-pack logs
```

---
钱包地址（方便复制）：

```
钱包1  kaspa:qqrwgt0kpe7c58y90plagddqpsky9046eh88epf0t2zsje3z4vxg7hfrgqh4m
钱包2  kaspa:qrhgpcrt303kaz3pvsz3ulm95lrjet6jp956e2qrmhe5tqna3ezh5hrtklcqn
```
