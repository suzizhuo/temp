# kHeavyHash 满血挖矿脚本包（Linux / Kryptex KAS / lolMiner 1.97）

按 `../方案.MD` 实现的完整执行包。目标：Linux + NVIDIA 机器满血挖 Kaspa，
算力直打你的钱包；三处配置（算法 / 钱包 / 矿池）联动即可切换币种。

## 0. 当前路线：KASPA（lolMiner 1.97 + Kryptex）

`1.98a` 已删除 `--algo KASPA`。本包锁定 **lolMiner 1.97**（仍支持 KASPA）。
Karlsen 海外池在当前网络被 DNS 污染，Kryptex 已下架 KLS；实测能握手的是
Kryptex Kaspa：`kas-ru.kryptex.network:7011`（主）/ `kas-hk:7011`（备）。

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `ALGO` | `KASPA` | 透传 `--algo` |
| `POOL_COIN` | `kaspa` | 币种标识（地址前缀、监控标题、提示文案用） |
| `ADDR_PREFIX` | `kaspa:` | 地址前缀，`wallet_tool.sh` 与 `run_instance.sh` 校验共用 |

`WALLET_1` / `WALLET_2` 已填入你的两个 `kaspa:` 地址。单实例默认打钱包1；
两地址同时挖：`./start.sh --dual`。

> 榨干内存/GPU 的调优手段（`-ac` 锁最高核心+显存 clock 对、2.5GiB 大页、功耗墙、THP）与算法无关。

## 1. 文件清单

```
config.sh            币种/算法/钱包/矿池/超频/稳定性配置（核心）
install_deps.sh      装依赖 + 驱动检查
download_miner.sh    下载 lolMiner（sha256 校验）
mem_tune.sh          系统内存满血：2.5GiB 大页 / swappiness / THP / 可选 swapoff
oc_tune.sh           NVIDIA 满血调优（持久模式/-ac 锁频/功耗墙）+ 自动调 mem_tune
start.sh             启动挖矿（screen 后台；--dual 双实例双钱包）
run_instance.sh      单实例参数组装 + 崩溃守护循环（start.sh 内部调用）
stop.sh              停止
status.sh            状态/算力/份额
monitor.sh           实时监控（5s 刷新）
verify_pool.sh       矿池端口探测（TCP + stratum 握手）
wallet_tool.sh       钱包校验 / 切换默认钱包
emergency.sh         watchdog script 模式钩子
systemd_install.sh   开机自启（与 screen 二选一）
README.md            本文件
```

## 2. 满血激活四步

```bash
# 步骤 0：上传本目录到 Linux 机器，进入后给执行权限
cd kaspa-miner-pack && chmod +x *.sh

# 步骤 1：装依赖 + 下矿机（自动校验 sha256）
sudo ./install_deps.sh
./download_miner.sh     # 必须看到 [OK] .../lolMiner_linux/lolMiner 就绪

# 步骤 2：填你自己的钱包（必做，否则 start.sh 会在预检阶段拒绝启动）
vi config.sh           # 改 WALLET_1 / WALLET_2 / WORKER
./wallet_tool.sh verify

# 步骤 3：满血调优 + 启动
sudo ./oc_tune.sh      # 持久模式 + 每卡最高核心/显存 clock 对(-ac) + 系统内存大页
./start.sh             # 默认挖到钱包1
```

验证是否真的在挖：

```bash
./status.sh            # 看 Total Speed / Accepted
./monitor.sh           # 实时
# 或浏览器打开 http://<矿机IP>:4066/gui
```

收益核对：https://pool.kryptex.com/kas → 搜你的 `kaspa:` 地址。

## 3. 关键设计

- **矿机与版本**：lolMiner `1.97`（GitHub Releases，经 ghproxy；sha256 已锁定，不一致拒绝运行）。已有 1.98a 时 `./download_miner.sh` 会因版本戳不匹配而重下。
- **算法**：`ALGO`（`config.sh`）透传 `--algo`；默认 `KASPA`。
- **故障切换**：lolMiner 支持多组 `--pool/--user`（主池短时间掉线 5 次切下一组）。
- **满血关键参数**：
  - `oc_tune.sh` 在 `MEM_CLOCK_LOCK="*"` 时把每卡锁到官方支持的最高核心+显存 clock 对
    （`nvidia-smi -ac`，显存带宽与核心均拉满），比 `--mclk 810` 省电预设更激进；
    接线方式：改 `config.sh` 的 `MEM_CLOCK_LOCK="810"` 再跑 `./oc_tune.sh`。
    每张卡独立容错：某张卡不支持某项锁频只打印 `[!]` 并继续，不会中断整轮调优。
  - `--pl` 功耗墙、`--fan` 风扇；`POWER_LIMIT="*"` = 不设限（温度用 `T_STOP/T_START` 兜底）。
  - `--watchdog exit` + `run_instance.sh` 守护循环：矿机崩溃退出码 42 自动拉起；
    连续 3 次运行 <20 秒的非 42 退出会断然停掉并写日志（避免参数错误死循环刷日志）。
    `WATCHDOG_MODE=script` 时自动接上 `--watchdogscript emergency.sh`（该脚本需可执行）。
  - `--apiport` 网页统计面板 `/gui`；`--statsformat` 自定义统计项。
  - **双实例防抢卡**：`--dual` 时 `GPUS="*"` 自动取 `GPUS_2` 的补集给实例1；
    两组卡显式重叠会被拒绝并提示。
- **systemd 自启**（`systemd_install.sh`）：每个实例一个 service，直接 `exec run_instance.sh`
  （自带守护循环，不会像旧版经 `start.sh` 秒退导致 `Restart=always` 每 10s 空转重启）；
  `HOME` 按 `SUDO_USER` 的 passwd 条目取值（旧版 sudo 下会写成 `/root`）。
  `sudo ./systemd_install.sh --dual` 双实例；`sudo ./systemd_install.sh uninstall` 卸载。
- **内存满血**（`mem_tune.sh`，`oc_tune.sh` 自动调用）：`vm.nr_hugepages=1280`（2.5GiB）、
  `swappiness=10`、`vfs_cache_pressure=50`、`THP=madvise`；`SWAPOFF=1` 才执行 `swapoff -a`。
- **矿机能力自检**：`run_instance.sh` 启动前取一份 `lolMiner --help`，传了本构建不认识的
  参数（不同版本参数集有增减）会自动剔除并写日志——不猜版本，让矿机自己报家门。
  另外故意传一个假 `--algo` 骗取真实算法列表存到 `logs/lolMiner_algos.txt`，`ALGO`
  不在列表里会先警告。排查参数崩溃的逃生阀：`MINIMAL_MODE=1 ./start.sh`。
- **矿池探测**（`verify_pool.sh`）：DNS + TCP + stratum 握手，全端口并行（约 10 秒出结果），
  结果分 GOOD/HALF/BAD 三级；`--write` 把最佳池写回 `config.sh`。
- **日志与可诊断性**：`run_instance.sh` 一开始就建日志并把全部输出重定向进去，
  "log 下无任何内容"不再可能；`start.sh` 启动前预检（包布局 / screen / nvidia-smi /
  矿机二进制 / 钱包非占位符），失败即打印原因并自动 `tail -n 15` 日志。
- **双钱包两种用法**：
  1. 切换默认钱包：`./wallet_tool.sh switch 2` 然后 `./stop.sh && ./start.sh`
  2. 同一台机两张卡组分打两个钱包：改 `config.sh` 的 `GPUS_2`，然后 `./start.sh --dual`
     （实例1 → 钱包1 用 `GPUS`，实例2 → 钱包2 用 `GPUS_2`，API 端口自动错开）

## 4. 矿池与钱包格式（Kryptex KAS）

- 主池：`POOL_PRIMARY=stratum+tcp://kas-ru.kryptex.network:7011`
  （矿池页 https://pool.kryptex.com/kas ）。备池 `kas-hk.kryptex.network:7011`。
  `POOL_TRY_HOSTS` 是 **host:port 端点列表**，`./verify_pool.sh` 按端点探测。
  NXDOMAIN 会明确报「域名不存在」；Twitter/Facebook/Dropbox IP 会报 DNS 污染，
  不会误诊成防火墙或矿池下架。
- **钱包格式 `WALLET/WORKER`（斜杠式）**：`WORKER_SEP="/"`（Kryptex）。
  脚本把 `钱包/矿工` 拼进 `--user` 且不再传 `--worker`。
- `MINER_PASS=x`。

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| 启动即退出、日志无内容 | 已不可能：`run_instance.sh` 日志先行，直接 `tail -n 15 logs/kaspa-miner_current.log` |
| 日志出现 `terminate called ... basic_string::_M_construct null not valid`（rc=134） | 本版矿机不认某个参数。`run_instance.sh` 已按 `--help` 自动剔除（看日志里的 `[!] 矿机不支持参数` 行）；仍在抛：`MINIMAL_MODE=1 ./start.sh` 起最小集，再逐个加回 |
| 日志出现 `login failed` / 份额被拒 | 钱包格式不对：Kryptex 要 `WALLET/WORKER`（`WORKER_SEP="/"`）；确认 `config.sh` 的 `WORKER_SEP` 与矿池文档一致 |
| `pool connect failed` / 一直连不上 | 跑 `./verify_pool.sh`；显示 `[HALF] TCP 通但 stratum 无回应` 说明该域名池子没在跑这个币或被链路拦截：换 `POOL_TRY_HOSTS` 里的域名再探，`--write` 自动回写 |
| `[!] 钱包还是占位符未填` | `config.sh` 填你自己的 `kaspa:` 地址 |
| `[!] 包布局异常` | 目录被拆散了：`kaspa-miner-pack` 必须整体上传，不要只拷 `.sh` |
| `[!] 未找到矿机` | `./download_miner.sh` |
| `Error: --algo ... not supported` | 看 `logs/lolMiner_algos.txt` 里矿机实测支持的算法列表，把 `config.sh` 的 `ALGO` 改成其中的名字 |
| `未检测到 nvidia-smi` | 装驱动：`sudo apt install -y nvidia-driver-535 && sudo reboot` |
| 算力为 0 或极低 | `oc_tune.sh` 没跑：频率没锁；确认 `nvidia-smi` 里 clocks 已变化 |
| 功耗高想降温 | `MEM_CLOCK_LOCK="810"` 省电预设，再降 `POWER_LIMIT` |
| 想开机自启 | `sudo ./systemd_install.sh`（用了它就别再开 screen） |
| 切到钱包2 | `./wallet_tool.sh switch 2 && ./stop.sh && ./start.sh` |

## 6. 卸载

```bash
./stop.sh
sudo ./oc_tune.sh reset      # 清锁频（可选）
sudo ./mem_tune.sh reset     # 恢复 swappiness/THP（可选）
# 若装过 systemd：sudo ./systemd_install.sh 卸载命令见其输出
rm -rf kaspa-miner-pack logs
```

---

钱包地址格式 `kaspa:` + bech32 变体（version=0 / 32 字节 payload / 8 字符校验）。
校验命令：`./wallet_tool.sh verify`。
