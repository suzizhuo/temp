#!/usr/bin/env bash
# 单个矿机实例：拼 lolMiner 参数 + 守护循环（watchdog exit 42 / 崩溃自动重启）
# 由 start.sh 调用，不单独使用
# $1 = 钱包编号 1|2   $2 = 显卡列表("*" 或 "0,1")   $3 = API 端口   $4 = screen 会话名
#
# 约定：日志先行 + 全量重定向进日志。
#   早期失败（缺矿机、包被平铺、参数错）以前会死在 screen 里且不落盘，
#   导致 "log 下无任何内容"、看不到任何原因。现在所有输出都进 logs/<会话>_current.log。
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

WIDX="${1:?钱包编号 1|2}"
GPUS_N="${2:-*}"
API_PORT_N="${3:-$API_PORT}"
SESSION="${4:-kaspa-miner}"

is_on() { [ -n "$1" ] && [ "$1" != "*" ]; }   # "空 或 *" 表示不设置

# ---------------- 日志先行：任何早期失败都必须可诊断 ----------------
if ! mkdir -p "$LOG_DIR" 2>/dev/null; then
    LOG_DIR="/tmp"   # 包目录不可写时兜底，绝不静默丢失日志
fi
LOG="$LOG_DIR/${SESSION}_$(date +%Y%m%d_%H%M%S).log"
ln -sf "$LOG" "$LOG_DIR/${SESSION}_current.log" 2>/dev/null || true
echo "[$(date '+%F %T')] run_instance 启动 widx=$WIDX gpus=$GPUS_N api=$API_PORT_N sess=$SESSION" >> "$LOG"

# 从这里开始 stdout/stderr 全进日志；同时保留原始终端 fd 供 DRY_RUN 输出
exec 3>&1 4>&2
exec >> "$LOG" 2>&1

# ---------------- 包布局自检：只拷 .sh 到别处时 PACK_DIR 会指错，提前喊出来 ----------------
for need in config.sh download_miner.sh start.sh run_instance.sh; do
    if [ ! -f "$PACK_DIR/$need" ]; then
        echo "[!] 包布局异常：未找到 $PACK_DIR/$need"
        echo "    kaspa-miner-pack 必须整体上传/解压成一个目录，不要把 .sh 单独拷到别处再跑。"
        echo "    当前 PACK_DIR=${PACK_DIR}，请确认所有脚本都在同一目录。"
        exit 1
    fi
done

case "$WIDX" in
    1) WALLET="$WALLET_1" ;;
    2) WALLET="$WALLET_2" ;;
    # active：启动时再读 config.sh 的 ACTIVE_WALLET（wallet_tool.sh switch 之后不用重装服务）
    active)
        case "$ACTIVE_WALLET" in
            1) WALLET="$WALLET_1" ;;
            2) WALLET="$WALLET_2" ;;
            *) echo "[!] config.sh 的 ACTIVE_WALLET 必须是 1 或 2"; exit 1 ;;
        esac
        WIDX="$ACTIVE_WALLET" ;;
    *) echo "[!] 钱包编号必须是 1 / 2 / active"; exit 1 ;;
esac

# 钱包地址基本检查：前缀须为 config.sh 的 ADDR_PREFIX，且不能还是占位符
if [ "${WALLET:0:${#ADDR_PREFIX}}" != "$ADDR_PREFIX" ]; then
    echo "[!] 钱包地址前缀应为 ${ADDR_PREFIX}，当前：$WALLET"
    echo "    请在 config.sh 填入 ${ADDR_PREFIX} 开头的真实地址（当前算法 ${ALGO} / 矿机 ${MINER_VERSION}）。"
    exit 1
fi
case "$WALLET" in
    *PLACEHOLDER*) echo "[!] 钱包还是占位符未填：$WALLET —— 改 config.sh 的 WALLET_1/WALLET_2"; exit 1 ;;
esac

# ---------------- 组装 lolMiner 参数 ----------------
# 矿池的登录串格式由 config.sh 的 WORKER_SEP 决定：
#   WORKER_SEP="/"：WALLET/WORKER 直接拼进 --user（kryptex 等斜杠式矿池）；
#                    此时绝不再传 --worker，否则 lolMiner 会再追加一个 .worker，
#                    登录名变成 钱包/rig.lolMiner，直接被池子拒收。
#   WORKER_SEP="."：WALLET 走 --user，WORKER 由 lolMiner 的 --worker 追加
#                    （woolypooly 等点号式矿池）。
case "$WORKER_SEP" in
    /) USER_STR="${WALLET}/${WORKER}" ;;
    *) USER_STR="$WALLET" ;;
esac

if [ "$WORKER_SEP" = "/" ]; then
    ARGS=( --algo "$ALGO" --pass "$MINER_PASS" )
else
    ARGS=( --algo "$ALGO" --worker "$WORKER" --pass "$MINER_PASS" )
fi

# 矿池（lolMiner 多组 --pool/--user 即原生故障切换；每组用同一个登录串）
if is_on "$POOL_TLS"; then
    ARGS+=( --pool "$POOL_TLS" --user "$USER_STR" )
fi
for p in $POOL_PRIMARY $POOL_BACKUPS; do
    if is_on "$p"; then
        ARGS+=( --pool "$p" --user "$USER_STR" )
    fi
done

# 显卡选择（lolMiner --devices 逗号列表）
if is_on "$GPUS_N"; then
    ARGS+=( --devices "$GPUS_N" )
fi

# 满血超频（这些参数会被 linux 下的 NVML 应用，同样可交给 oc_tune.sh）
if is_on "$CORE_CLOCK_LOCK"; then ARGS+=( --cclk "$CORE_CLOCK_LOCK" ); fi
if is_on "$MEM_CLOCK_LOCK"; then
    ARGS+=( --mclk "$MEM_CLOCK_LOCK" )
elif is_on "$MEM_CLOCK_OFFSET"; then
    ARGS+=( --moff "$MEM_CLOCK_OFFSET" )
fi
if is_on "$POWER_LIMIT"; then ARGS+=( --pl "$POWER_LIMIT" ); fi
if is_on "$FAN_SPEED";   then ARGS+=( --fan "$FAN_SPEED" ); fi

# API / 温度保护 / 看门狗 / 统计
ARGS+=( --apiport "$API_PORT_N" )
if [ "$WATCHDOG_MODE" != "off" ] && [ -n "$WATCHDOG_MODE" ]; then
    ARGS+=( --watchdog "$WATCHDOG_MODE" )
    # script 模式：lolMiner 走 --watchdogscript 调外部脚本；旧版只传了 --watchdog script，
    # emergency.sh 从来没被接上（死代码）。这里补上接线，并确保脚本可执行。
    if [ "$WATCHDOG_MODE" = "script" ]; then
        if [ -f "$PACK_DIR/emergency.sh" ]; then
            [ -x "$PACK_DIR/emergency.sh" ] || chmod +x "$PACK_DIR/emergency.sh" 2>/dev/null || true
            ARGS+=( --watchdogscript "$PACK_DIR/emergency.sh" )
        else
            echo "[!] WATCHDOG_MODE=script 但找不到 $PACK_DIR/emergency.sh，回退 exit 模式"
            ARGS+=( --watchdog exit )
        fi
    fi
fi
if is_on "$T_STOP";  then ARGS+=( --tstop "$T_STOP" ); fi
if is_on "$T_START"; then ARGS+=( --tstart "$T_START" ); fi
if is_on "$STATS_FORMAT"; then ARGS+=( --statsformat "$STATS_FORMAT" ); fi
if is_on "$SILENCE"; then ARGS+=( --silence "$SILENCE" ); fi

# ---------------- MINIMAL_MODE：只用最小保守参数集，排查参数崩溃时的逃生阀 ----------------
# MINIMAL_MODE=1 ./start.sh —— 只留 algo/pool/user/apiport，其余全不传
if [ "${MINIMAL_MODE:-0}" = "1" ]; then
    echo "[*] MINIMAL_MODE=1：仅用最小参数集启动（--algo/--pool/--user/--apiport），用于定位参数问题"
    ARGS=( --algo "$ALGO" )
    if is_on "$POOL_TLS"; then ARGS+=( --pool "$POOL_TLS" --user "$USER_STR" ); fi
    for p in $POOL_PRIMARY $POOL_BACKUPS; do
        is_on "$p" && ARGS+=( --pool "$p" --user "$USER_STR" )
    done
    ARGS+=( --apiport "$API_PORT_N" )
fi

# ---------------- 矿机能力自检：拿它自己的 --help 过滤不认识的参数 ----------------
# 踩坑记录：不同版本 lolMiner 参数集有增减，传了本构建不认识的参数不会温和报错，
# 而是直接 SIGABRT：
#   terminate called after throwing an instance of 'std::logic_error'
#     what():  basic_string::_M_construct null not valid      （rc=134，秒退）
# 旧版脚本只会进入重启循环刷日志。现在启动前先要一份 --help，不支持的就地剔除并写日志。
HELP_FILE="$LOG_DIR/lolMiner_help.txt"
ALGO_FILE="$LOG_DIR/lolMiner_algos.txt"

# --help 抓回来的东西得像份真 help（至少同时提到 --algo 和 --pool），否则不拿它当过滤依据，
# 防止旧版/损坏输出被缓存后把参数全部误剃光
help_looks_real() {
    [ -s "$HELP_FILE" ] || return 1
    grep -q -F -- "--algo" "$HELP_FILE" && grep -q -F -- "--pool" "$HELP_FILE"
}
flag_supported() {  # $1 = --flag；help 不像样时保守视为支持（不猜）
    help_looks_real || return 0
    grep -q -F -- "$1" "$HELP_FILE"
}

if [ -x "$MINER_BIN" ]; then
    if ! help_looks_real; then
        "$MINER_BIN" --help > "$HELP_FILE" 2>&1 || true
    fi
    if help_looks_real && [ "${MINIMAL_MODE:-0}" != "1" ]; then
        _new=(); _skip=0
        for _a in ${ARGS[@]+"${ARGS[@]}"}; do
            case "$_a" in
                --*)
                    if flag_supported "$_a"; then
                        _new+=("$_a"); _skip=0
                    else
                        echo "[!] 矿机不支持参数 ${_a}（不在 ${HELP_FILE} 列表），已自动剔除"
                        _skip=1   # 连它的值一起丢掉
                    fi ;;
                *)
                    if [ "$_skip" = "1" ]; then _skip=0; else _new+=("$_a"); fi ;;
            esac
        done
        ARGS=(${_new[@]+"${_new[@]}"})
    fi

    # 算法自检：故意传个假 algo，让矿机吐出它真实支持的算法列表
    # （真矿机的报错里一定带 "List of supported algorithms"，拿这个当抓成功的标记）
    if [ ! -s "$ALGO_FILE" ] || ! grep -qi "algorithms" "$ALGO_FILE"; then
        "$MINER_BIN" --algo __PROBE_NOT_AN_ALGO__ > "$ALGO_FILE" 2>&1 || true
    fi
    if grep -qi "algorithms" "$ALGO_FILE" && ! grep -q -w -- "$ALGO" "$ALGO_FILE"; then
        echo "[!] 警告：矿机可能不支持算法 ${ALGO}"
        echo "    实测支持列表见 ${ALGO_FILE}；若启动即退，把 config.sh 的 ALGO 改成列表中的名字。"
    fi
fi

# 干跑模式：只打印最终命令，不启动矿机（DRY_RUN=1 ./run_instance.sh 1 "*" 4066 test）
if [ "${DRY_RUN:-0}" = "1" ]; then
    exec 1>&3 2>&4   # 还原终端，让 DRY_RUN 输出直接可见
    if [ "${#ARGS[@]}" -gt 0 ]; then
        echo "[DRY-RUN] $MINER_BIN ${ARGS[*]}"
    else
        echo "[DRY-RUN] ${MINER_BIN}（参数集为空，检查过滤逻辑与配置）"
    fi
    exit 0
fi

if [ ! -x "$MINER_BIN" ]; then
    echo "[!] 未找到矿机：$MINER_BIN"
    echo "    先运行：cd \"$PACK_DIR\" && ./download_miner.sh"
    echo "    下载失败多为网络问题：curl -I \"$MINER_URL\" 看能否通 GitHub。"
    exit 1
fi

# 空参数集最后防线（真 help 至少会保留 --algo；走到这里说明过滤逻辑出了问题）
if [ "${#ARGS[@]}" -eq 0 ]; then
    echo "[!] 参数集为空，拒绝启动：检查 ${HELP_FILE} 内容与 config.sh"
    exit 1
fi

{
    echo "==== $(date '+%F %T') 启动 ===="
    echo "钱包：   $WALLET"
    echo "矿工：   ${WORKER}（分隔符 ${WORKER_SEP}）"
    echo "登录串： $USER_STR"
    echo "显卡：   $GPUS_N"
    if [ -n "$POOL_BACKUPS" ]; then
        echo "矿池：   ${POOL_PRIMARY} （故障切换：${POOL_BACKUPS}）"
    else
        echo "矿池：   ${POOL_PRIMARY} （无备池）"
    fi
    echo "API：    http://127.0.0.1:${API_PORT_N}/gui"
    echo "命令：   $MINER_BIN ${ARGS[*]}"
    echo "======================="
} >> "$LOG"

FAST_FAILS=0
FAST_FAIL_WINDOW=20    # 单次运行小于此秒且非 watchdog 退出码，判定为快速失败
FAST_FAIL_LIMIT=3      # 连续如此多次后断然退出，避免参数错误死循环刷日志
while true; do
    set +e
    T0=$(date +%s)
    "$MINER_BIN" "${ARGS[@]}" >> "$LOG" 2>&1
    RC=$?
    T1=$(date +%s)
    set -e
    DUR=$((T1 - T0))
    if [ "$RC" = "42" ]; then
        FAST_FAILS=0   # watchdog 退出由 lolMiner 自身判定，继续重启
    elif [ "$DUR" -lt "$FAST_FAIL_WINDOW" ]; then
        FAST_FAILS=$((FAST_FAILS + 1))
        echo "[$(date '+%F %T')] 矿机退出 rc=${RC} 耗时 ${DUR}s（快速失败 #${FAST_FAILS}），${RESTART_DELAY}s 后重启" >> "$LOG"
        if [ "$FAST_FAILS" -ge "$FAST_FAIL_LIMIT" ]; then
            echo "[$(date '+%F %T')] 连续 ${FAST_FAIL_LIMIT} 次快速失败，断然退出" >> "$LOG"
            # 把最后的现场留在日志里，别让用户去翻 core dump
            case "$RC" in
                134)
                    echo "[诊断] rc=134 = C++ 运行时 abort（典型：传了本版矿机不认识的参数，或参数值为空）" >> "$LOG"
                    echo "[诊断] 已自动按 ${HELP_FILE} 过滤参数；若仍在抛，试 MINIMAL_MODE=1 ./start.sh" >> "$LOG"
                    echo "[诊断] 并贴出 ${LOG} 里 terminate 之上最近 10 行原文" >> "$LOG" ;;
                139)
                    echo "[诊断] rc=139 = 段错误，多为驱动/CUDA 版本不匹配或显存溢出" >> "$LOG" ;;
                127)
                    echo "[诊断] rc=127 = 矿机文件不存在或不可执行，重跑 ./download_miner.sh" >> "$LOG" ;;
                126)
                    echo "[诊断] rc=126 = 矿机不可执行（权限/架构不符），检查 chmod 与下载包是否为 Lin64" >> "$LOG" ;;
            esac
            exit 1
        fi
    else
        FAST_FAILS=0
        echo "[$(date '+%F %T')] 矿机退出 rc=${RC}，${RESTART_DELAY}s 后重启" >> "$LOG"
    fi
    sleep "$RESTART_DELAY"
done
