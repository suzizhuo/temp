#!/usr/bin/env bash
# ============================================================
#  kHeavyHash 满血挖矿配置（Kryptex KAS / lolMiner 1.97）
#  本文件被其它脚本 source，请勿在此处 set -e 之类
# ============================================================

# 脚本包自身目录（自动定位，无需修改）
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------- 币种与算法 ----------------
# lolMiner 1.98a 已移除 --algo KASPA；本包回退到 1.97（仍支持 KASPA）。
# 当前网络下 Karlsen 海外池 DNS 被污染，Kryptex 已下架 KLS；
# 实测能 stratum 握手的是 Kryptex Kaspa：kas-ru / kas-hk :7011。
# 切换币种需三处联动：ALGO + 钱包 + 矿池域名（POOL_COIN）。
ALGO="KASPA"
POOL_COIN="kaspa"              # 币种标识：地址前缀校验、监控标题、提示文案共用
ADDR_PREFIX="kaspa:"           # 地址前缀；wallet_tool.sh 校验与 run_instance.sh 预检共用

# ---------------- 钱包 ----------------
# 单实例默认打到 ACTIVE_WALLET；两地址同时挖：./start.sh --dual
WALLET_1="kaspa:qqrwgt0kpe7c58y90plagddqpsky9046eh88epf0t2zsje3z4vxg7hfrgqh4m"
WALLET_2="kaspa:qrhgpcrt303kaz3pvsz3ulm95lrjet6jp956e2qrmhe5tqna3ezh5hrtklcqn"

# 单实例默认打到 ACTIVE_WALLET 指定的地址；切换：./wallet_tool.sh switch 1|2
ACTIVE_WALLET=1

# ---------------- 矿工与矿池 ----------------
WORKER="linux-rig-01"        # 矿池后台区分机器，建议改成你的机器名
# 钱包/矿工拼接分隔符：矿池文档的格式决定
#   "/" = WALLET/WORKER   （kryptex 等斜杠式：拼进 --user，不再传 --worker）
#   "." = WALLET.WORKER   （woolypooly 等点号式：由 lolMiner --worker 追加）
WORKER_SEP="/"               # Kryptex 文档：WALLET/WORKER 拼进 --user

MINER_PASS="x"               # kryptex 密码固定填 x

# Kryptex Kaspa（本机实测：kas-ru:7011 EthereumStratum GOOD；kas-hk:7011 间歇可用）
POOL_HOST="kas-ru.kryptex.network"
# 矿池网页（查收益用）；换池时改这里，start.sh / status.sh 的提示自动跟着变
POOL_WEB="https://pool.kryptex.com/kas"
# verify_pool.sh 探测的候选端点（空格或逗号分隔，推荐 host:port）
POOL_TRY_HOSTS="kas-ru.kryptex.network:7011 kas-hk.kryptex.network:7011 kas.kryptex.network:7777"
POOL_TRY_PORTS="7011"
# 主池（lolMiner 参数：--pool/--user 可重复，实现原生故障切换）
POOL_PRIMARY="stratum+tcp://${POOL_HOST}:7011"

# 备池：主池短时间掉线后 lolMiner 自动切下一组。
POOL_BACKUPS="stratum+tcp://kas-hk.kryptex.network:7011 stratum+tcp://kas.kryptex.network:7777"

# SSL 池（选项；若矿池开启 TLS 端口，把主池改成其地址即可）
POOL_TLS=""

# ---------------- 矿机程序 ----------------
MINER_VERSION="1.97"
# 1.98a 无 KASPA。GitHub 直连常超时，download_miner.sh 会再试 ghproxy。
# MINER_SHA256 首次下载成功后由 download_miner.sh 写回锁定。
MINER_URL="https://github.com/Lolliedieb/lolMiner-releases/releases/download/1.97/lolMiner_v1.97_Lin64.tar.gz"
MINER_URL_MIRROR="https://ghproxy.net/https://github.com/Lolliedieb/lolMiner-releases/releases/download/1.97/lolMiner_v1.97_Lin64.tar.gz"
MINER_SHA256="PENDING_LOLMINER_197_SHA256"
MINER_BIN="$PACK_DIR/lolMiner_linux/lolMiner"

# ---------------- 日志 / API ----------------
LOG_DIR="$PACK_DIR/logs"
API_PORT="4066"             # lolMiner --apiport，浏览器 http://矿机IP:4066/gui 看统计
API_PORT_2="4067"           # 双实例时第二个实例的 API 端口

# ---------------- 显卡 ----------------
# "*" = 全部显卡；或逗号列表，如 "0,1,2,3"（lolMiner --devices）
GPUS="*"
GPUS_2="4,5,6,7"            # start.sh --dual 时第二实例使用的显卡

# ---------------- 满血超频（oc_tune.sh 执行，可被命令行参数覆盖）----------------
PERSISTENCE=1               # 1 = 开启 nvidia-smi 持久模式（强烈建议）
POWER_LIMIT="*"             # 功耗墙 W，例 300；"*" = 不动
CORE_CLOCK_LOCK="*"         # 核心锁频 MHz，例 1500；"*" = 不动（lolMiner 文档：Ampere/Turing 生效）
MEM_CLOCK_LOCK="*"          # 显存锁频 MHz。"*" = 不锁，由 lolMiner/oc_tune.sh 决定；
                            #   oc_tune.sh 会把每卡锁到该卡支持的最高核心+显存 clock 对（-ac），真榨 GPU
                            #   保守省电预设填 "810"（HeavyHash 显存带宽压力小，锁低频功耗暴降）
MEM_CLOCK_OFFSET=""         # 显存偏移 MHz（与 MEM_CLOCK_LOCK 二选一）
FAN_SPEED="*"               # 风扇 %；"*" = 不动

# ---------------- 运行稳定性 ----------------
WATCHDOG_MODE="exit"        # off | exit | script（exit：崩溃退出码 42，外层自动重启）
RESTART_DELAY=5             # 矿机退出后重启等待秒数
T_START=""                  # 低于该温度恢复挖矿，例 70；空 = 不启用
T_STOP=""                   # 达到该温度停该卡，例 83；空 = 不启用
# STATS_FORMAT 留空 = 不传 --statsformat。此参数在部分版本取值不当会直接 SIGABRT
# （basic_string::_M_construct null not valid），run_instance.sh 也会按矿机 --help 自动剔除
# 不支持的参数；确认自己的版本支持后可按 lolMiner 文档填回。
STATS_FORMAT=""
SILENCE=1                   # 0 最详细 / 1 无 job / 2 无 share / 3 只出统计

# MINIMAL_MODE=1 时 start.sh/run_instance.sh 只用 --algo/--pool/--user/--apiport 启动，
# 是参数崩溃时的逃生阀（MINIMAL_MODE=1 ./start.sh）。正常挖矿保持 0。
MINIMAL_MODE=0

# ---------------- 内存满血（mem_tune.sh，oc_tune.sh 执行）---------------
MEM_TUNE=1                  # 1 = oc_tune.sh 时顺便调优系统内存（需 root）
HUGEPAGES=1280              # 1280 × 2MiB = 2.5GiB 大页
SWAPPINESS=10               # 降低交换倾向，尽量留在物理内存
SWAPOFF=0                   # 1 = swapoff -a（慎用：仅确认无 OOM 风险后再开）
THP_MODE="madvise"          # madvise | always（transparent hugepages）

# ---------------- 目录 ----------------
MINER_DIR="$PACK_DIR/lolMiner_linux"
