#!/usr/bin/env bash
# 下载并校验 lolMiner（版本与 sha256 在 config.sh 中锁定）
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/config.sh"

TAR="$PACK_DIR/lolMiner_v${MINER_VERSION}_Lin64.tar.gz"
STAMP="$MINER_DIR/.miner_version"

# 二进制在但丢了执行位（拷贝/解压丢权限时常见）：补上就好，不用重下
if [ -f "$MINER_BIN" ] && [ ! -x "$MINER_BIN" ]; then
    echo "[*] 发现矿机不可执行，补执行位：$MINER_BIN"
    chmod +x "$MINER_BIN" || true
fi

NEED_DL=1
if [ -x "$MINER_BIN" ] && [ -f "$STAMP" ] && [ "$(cat "$STAMP" 2>/dev/null)" = "$MINER_VERSION" ]; then
    NEED_DL=0
elif [ -x "$MINER_BIN" ]; then
    echo "[*] 矿机版本不是 ${MINER_VERSION}（或无版本戳），将重新下载"
fi

if [ "$NEED_DL" = "1" ]; then
    echo "[+] 下载 lolMiner $MINER_VERSION ..."
    GOT=0
    for url in "$MINER_URL" "${MINER_URL_MIRROR:-}"; do
        [ -n "$url" ] || continue
        echo "    尝试 $url"
        if curl -fSL --retry 3 --retry-all-errors -o "$TAR" "$url"; then
            GOT=1
            break
        fi
        echo "    [!] 失败：$url"
    done
    if [ "$GOT" != "1" ]; then
        echo "[!] 所有镜像都下失败了 lolMiner $MINER_VERSION"
        exit 1
    fi

    echo "[+] 校验 sha256..."
    ACTUAL="$(sha256sum "$TAR" | awk '{print $1}')"
    if [ -z "$MINER_SHA256" ] || [ "$MINER_SHA256" = "PENDING_LOLMINER_197_SHA256" ]; then
        echo "    首次锁定 sha256：$ACTUAL"
        sed -i.bak "s/^MINER_SHA256=.*/MINER_SHA256=\"${ACTUAL}\"/" "$PACK_DIR/config.sh"
    elif [ "$ACTUAL" != "$MINER_SHA256" ]; then
        echo "[!] sha256 不匹配，下载可能损坏："
        echo "    期望 $MINER_SHA256"
        echo "    实际 $ACTUAL"
        rm -f "$TAR"
        exit 1
    else
        echo "    sha256 OK：$ACTUAL"
    fi

    echo "[+] 解压..."
    rm -rf "$PACK_DIR/miner_extract"
    mkdir -p "$PACK_DIR/miner_extract"
    tar -xzf "$TAR" -C "$PACK_DIR/miner_extract"
    rm -rf "$MINER_DIR"
    FOUND="$(find "$PACK_DIR/miner_extract" -maxdepth 2 -type f -name lolMiner | head -1)"
    if [ -z "$FOUND" ]; then
        echo "[!] 压缩包内未找到 lolMiner 可执行文件"
        exit 1
    fi
    mv "$(dirname "$FOUND")" "$MINER_DIR"
    rm -rf "$PACK_DIR/miner_extract"
    chmod +x "$MINER_BIN"
    printf '%s\n' "$MINER_VERSION" > "$STAMP"
else
    echo "[=] 已存在可用的矿机：$MINER_BIN（$MINER_VERSION）"
fi

echo "[+] 矿机信息："
"$MINER_BIN" --version 2>&1 | head -5 || true
echo "[OK] $MINER_BIN 就绪"
