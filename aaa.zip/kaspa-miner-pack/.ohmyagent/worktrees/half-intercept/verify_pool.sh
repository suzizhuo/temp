#!/usr/bin/env bash
# 矿池探测：DNS 预检 + TCP/stratum 握手（全端点并行）+ 结果分级诊断
# 用法：
#   ./verify_pool.sh                 探测 config.sh 的 POOL_TRY_HOSTS（可写 host:port）
#   ./verify_pool.sh host1 host2 ... 探测指定域名（可带 :port）
#   ./verify_pool.sh --write         探测通过后把最佳池写回 config.sh 的 POOL_PRIMARY
#
# 结果分三级（用户常见困惑：TCP 通但矿机连不上，就是这个 HALF 级）：
#   GOOD   stratum 有握手回应 —— 可用
#   HALF   TCP 能连上但 stratum 无回应 —— 端口活着但后端不服务：
#         典型原因：矿池没上这个币 / 域名指向了通用前端 / 链路被中间设备拦截
#   BAD    TCP 都连不上 或 DNS NXDOMAIN（主机名已从公共 DNS 删除）
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"
PROBE_PY="$PACK_DIR/scripts/poolprobe.py"

WRITE_BACK=0
if [ "${1:-}" = "--write" ]; then WRITE_BACK=1; shift; fi

if [ $# -gt 0 ]; then
    HOSTS="$*"
else
    HOSTS="${POOL_TRY_HOSTS:-$POOL_HOST}"
fi
HOSTS="${HOSTS//,/ }"
# 端口候选：仅当 HOSTS 里是裸域名时使用。host:port 端点自带端口，不再做笛卡尔积。
PORTS="${POOL_TRY_PORTS:-}"
[ -n "$PORTS" ] || PORTS="$(printf '%s\n' "$POOL_PRIMARY" | sed -n 's/.*://p')"
[ -n "$PORTS" ] || PORTS="3333"

OUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/poolprobe.XXXXXX")"
trap 'rm -rf "$OUT_DIR"' EXIT

probe() {  # $1=host $2=port $3=序号
    python3 "$PROBE_PY" probe "$1" "$2" "$OUT_DIR/$3"
}

TARGETS="$(python3 "$PROBE_PY" parse "$HOSTS" "$PORTS")"
if [ -z "$TARGETS" ]; then
    echo "[!] 没有可探测的端点。检查 POOL_TRY_HOSTS / 命令行参数。"
    exit 1
fi

echo "[*] 并行探测端点（host:port，不是主机×端口笛卡尔积）："
echo "$TARGETS" | sed 's/^/    /'
echo "    每个端点独立 4s TCP + 4s stratum 超时，全部并发"
i=0
while IFS= read -r ep; do
    [ -n "$ep" ] || continue
    host="${ep%:*}"
    port="${ep##*:}"
    i=$((i+1))
    probe "$host" "$port" "$i" &
done <<< "$TARGETS"
wait

GOOD=(); HALF=0; BAD=0; DNS_LABELS=""; HALF_LABELS=""
n=0
while IFS= read -r ep; do
    [ -n "$ep" ] || continue
    n=$((n+1))
    line="$(cat "$OUT_DIR/$n" 2>/dev/null || echo 'BAD|OTHER|探测未执行')"
    lvl="${line%%|*}"; rest="${line#*|}"
    label="${rest%%|*}"; msg="${rest#*|}"
    case "$lvl" in
        GOOD) echo "  [GOOD] ${ep}  ${msg}"; GOOD+=("$ep") ;;
        HALF)
            echo "  [HALF] ${ep}  ${msg}"
            HALF=$((HALF+1))
            HALF_LABELS="${HALF_LABELS:+$HALF_LABELS,}$label"
            ;;
        *)
            echo "  [BAD ] ${ep}  ${msg}"
            BAD=$((BAD+1))
            DNS_LABELS="${DNS_LABELS:+$DNS_LABELS,}$label"
            ;;
    esac
done <<< "$TARGETS"
echo ""

echo "==================== 结论 ===================="
if [ "${#GOOD[@]}" -gt 0 ]; then
    echo "[OK] 可用端口：${GOOD[*]}"
    BEST="${GOOD[0]}"
    echo "    当前 POOL_PRIMARY=$POOL_PRIMARY"
    if [ "$POOL_PRIMARY" != "stratum+tcp://${BEST}" ]; then
        echo "    建议最佳：stratum+tcp://${BEST}"
        if [ "$WRITE_BACK" = "1" ]; then
            sed -i.bak "s|^POOL_PRIMARY=.*|POOL_PRIMARY=\"stratum+tcp://${BEST}\"|" "$PACK_DIR/config.sh"
            echo "[OK] 已写回 config.sh（备份 config.sh.bak）"
        else
            echo "    执行 ./verify_pool.sh --write 可自动写回 config.sh"
        fi
    fi
    exit 0
fi
if [ "$HALF" -gt 0 ]; then
    SUMH="$(python3 "$PROBE_PY" summarize-half "${HALF_LABELS}")"
    echo "[!] TCP 能连但 stratum 全部无回应：${SUMH}"
    echo "    处理：换网络/代理后再跑 ./verify_pool.sh；"
    echo "          只有 tcp= 很小且 IP 不像社交网段时，才去换 ${ALGO} 矿池域名。"
    exit 1
fi
SUM="$(python3 "$PROBE_PY" summarize "${DNS_LABELS}")"
echo "[!] TCP 全部不通：${SUM}"
case "$SUM" in
    *NXDOMAIN*) ;;
    *) echo "    或换网络（部分地区到海外池子会被干扰）后重试。" ;;
esac
exit 1
