#!/usr/bin/env python3
"""Parse pool endpoints and classify DNS failures for verify_pool.sh."""
from __future__ import annotations

import json
import socket
import time


def parse_targets(hosts, default_ports):
    tokens = []
    for chunk in str(hosts or "").replace(",", " ").split():
        if chunk:
            tokens.append(chunk)
    ports = []
    for chunk in str(default_ports or "").replace(",", " ").split():
        if chunk:
            ports.append(int(chunk))
    if not ports:
        ports = [3333]

    out = []
    seen = set()
    for raw in tokens:
        host, port = _split_endpoint(raw)
        if port is not None:
            item = (host, port)
            if item not in seen:
                seen.add(item)
                out.append(item)
            continue
        for p in ports:
            item = (host, p)
            if item not in seen:
                seen.add(item)
                out.append(item)
    return out


def _split_endpoint(raw):
    u = str(raw).strip()
    for prefix in ("stratum+tcp://", "stratum+ssl://", "stratum://", "tcp://"):
        if u.lower().startswith(prefix):
            u = u[len(prefix) :]
            break
    if u.startswith("[") and "]" in u:
        host, rest = u[1:].split("]", 1)
        if rest.startswith(":") and rest[1:].isdigit():
            return host, int(rest[1:])
        return host, None
    if ":" in u:
        host, maybe_port = u.rsplit(":", 1)
        if maybe_port.isdigit() and host:
            return host, int(maybe_port)
    return u, None


def dns_fail_label(exc):
    errno = getattr(exc, "errno", None)
    msg = str(exc).lower()
    if errno in (-2, 8, socket.EAI_NONAME):
        return "NXDOMAIN"
    needles = (
        "name or service not known",
        "nodename nor servname",
        "not known",
        "nxdomain",
    )
    if any(n in msg for n in needles):
        return "NXDOMAIN"
    return "OTHER"


# GFW 常见假 IP：Facebook / Twitter / Dropbox 段。解析到这里再“TCP 通”不是矿池。
_POISON_CIDRS = (
    ("157.240.0.0", 16),
    ("31.13.0.0", 16),
    ("162.125.0.0", 16),
    ("104.244.40.0", 21),
    ("108.160.160.0", 20),
    ("199.16.156.0", 22),
    ("168.143.0.0", 16),
)


def _ip_int(ip):
    parts = str(ip).split(".")
    if len(parts) != 4:
        return None
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None
    if any(n < 0 or n > 255 for n in nums):
        return None
    return (nums[0] << 24) | (nums[1] << 16) | (nums[2] << 8) | nums[3]


def is_poison_ip(ip):
    n = _ip_int(ip)
    if n is None:
        return False
    for net, bits in _POISON_CIDRS:
        base = _ip_int(net)
        if base is None:
            continue
        mask = (0xFFFFFFFF << (32 - bits)) & 0xFFFFFFFF
        if (n & mask) == (base & mask):
            return True
    return False


def classify_half(ip, tcp_ms, timeout_ms=4000):
    if is_poison_ip(ip):
        return "POISON"
    try:
        ms = int(tcp_ms)
    except (TypeError, ValueError):
        ms = 0
    if ms >= max(2500, int(timeout_ms * 0.6)):
        return "INTERCEPT"
    return "HALF"


def half_message(ip, tcp_ms, label):
    if label == "POISON":
        return (
            f"TCP 通（{ip} tcp={tcp_ms}ms）但 stratum 无回应："
            "DNS 污染到社交网段，不是矿池服务"
        )
    if label == "INTERCEPT":
        return (
            f"TCP 通（{ip} tcp={tcp_ms}ms）但 stratum 无回应："
            "握手过慢，链路被中间设备拦截"
        )
    return (
        f"TCP 通（{ip} tcp={tcp_ms}ms）但 stratum 无回应："
        "池子没回话（没上这个币/后端挂了）"
    )


def summarize_all_half(labels):
    labels = list(labels or [])
    if any(x in ("POISON", "INTERCEPT") for x in labels):
        return (
            "DNS 被污染或链路被中间设备拦截："
            "解析落到社交网段 IP，或 TCP 握手过慢后不讲 stratum。"
            "换网络或代理后再探；当前结果不能当作矿池已下架 KARLSENV2。"
        )
    return "TCP 能连但 stratum 无回应：池子可能没上这个币或后端挂了。"


def summarize_all_bad(labels):
    labels = list(labels or [])
    if labels and all(x == "NXDOMAIN" for x in labels):
        return (
            "域名不存在（NXDOMAIN）：主机名已从公共 DNS 删除。"
            "Kryptex 已下架 KLS。把 POOL_TRY_HOSTS 改成 host:port 列表后重试。"
        )
    return "检查 DNS、防火墙、外网出口"


def probe_one(host, port, timeout=4):
    t0 = time.time()
    try:
        ip = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)[0][4][0]
    except Exception as e:
        return "BAD", f"DNS 解析失败：{e}", dns_fail_label(e)
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
        tcp_ms = int((time.time() - t0) * 1000)
    except Exception as e:
        rtt = int((time.time() - t0) * 1000)
        return "BAD", f"TCP 不通（{rtt}ms）：{type(e).__name__}", "TCP"
    try:
        s.settimeout(timeout)
        s.sendall(
            (
                json.dumps(
                    {"id": 1, "method": "mining.subscribe", "params": ["poolprobe/1.0"]}
                )
                + "\n"
            ).encode()
        )
        data = s.recv(2048)
    except Exception:
        label = classify_half(ip, tcp_ms, timeout_ms=int(timeout * 1000))
        return "HALF", half_message(ip, tcp_ms, label), label
    finally:
        try:
            s.close()
        except Exception:
            pass
    text = data.decode(errors="replace").strip()
    first = text.splitlines()[0] if text else "(空)"
    rtt = int((time.time() - t0) * 1000)
    return "GOOD", f"{rtt}ms  stratum 回应：{first[:100]}", "GOOD"


def main(argv):
    import sys

    if len(argv) < 2:
        sys.stderr.write("usage: poolprobe.py parse|probe|summarize ...\n")
        return 2
    cmd = argv[1]
    if cmd == "parse":
        hosts = argv[2] if len(argv) > 2 else ""
        ports = argv[3] if len(argv) > 3 else ""
        for host, port in parse_targets(hosts, ports):
            sys.stdout.write(f"{host}:{port}\n")
        return 0
    if cmd == "probe":
        host, port, outfile = argv[2], int(argv[3]), argv[4]
        lvl, msg, label = probe_one(host, port)
        with open(outfile, "w") as f:
            f.write(f"{lvl}|{label}|{msg}")
        return 0
    if cmd == "summarize":
        labels = argv[2].split(",") if len(argv) > 2 and argv[2] else []
        sys.stdout.write(summarize_all_bad(labels) + "\n")
        return 0
    if cmd == "summarize-half":
        labels = argv[2].split(",") if len(argv) > 2 and argv[2] else []
        sys.stdout.write(summarize_all_half(labels) + "\n")
        return 0
    sys.stderr.write(f"unknown command: {cmd}\n")
    return 2


if __name__ == "__main__":
    import sys

    raise SystemExit(main(sys.argv))
