#!/usr/bin/env python3
"""RED tests for pool endpoint parsing and NXDOMAIN diagnosis."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from poolprobe import (
    classify_half,
    dns_fail_label,
    is_poison_ip,
    parse_targets,
    summarize_all_bad,
    summarize_all_half,
)


class ParseTargetsTest(unittest.TestCase):
    def test_bare_host_uses_default_ports(self):
        self.assertEqual(
            parse_targets("kls.kryptex.network", "7022"),
            [("kls.kryptex.network", 7022)],
        )

    def test_host_port_is_one_endpoint_not_cartesian(self):
        got = parse_targets(
            "kls.2miners.com:2020 karlsen.woolypooly.com:3333", "7022"
        )
        self.assertEqual(
            got,
            [
                ("kls.2miners.com", 2020),
                ("karlsen.woolypooly.com", 3333),
            ],
        )

    def test_stratum_url(self):
        self.assertEqual(
            parse_targets("stratum+tcp://de.karlsen.herominers.com:11450", "3333"),
            [("de.karlsen.herominers.com", 11450)],
        )

    def test_comma_separated_mixed(self):
        got = parse_targets("a.example,b.example:4444", "3333")
        self.assertEqual(got, [("a.example", 3333), ("b.example", 4444)])


class DnsLabelTest(unittest.TestCase):
    def test_linux_errno_minus2_is_nxdomain(self):
        self.assertEqual(
            dns_fail_label(OSError(-2, "Name or service not known")),
            "NXDOMAIN",
        )

    def test_macos_errno_8_is_nxdomain(self):
        self.assertEqual(
            dns_fail_label(OSError(8, "nodename nor servname provided, or not known")),
            "NXDOMAIN",
        )

    def test_all_nxdomain_summary_is_not_firewall(self):
        msg = summarize_all_bad(["NXDOMAIN", "NXDOMAIN"])
        self.assertNotIn("防火墙", msg)
        self.assertIn("域名不存在", msg)


class HalfInterceptTest(unittest.TestCase):
    def test_twitter_ip_is_poison(self):
        self.assertTrue(is_poison_ip("108.160.166.142"))
        self.assertTrue(is_poison_ip("104.244.46.63"))

    def test_facebook_and_dropbox_ips_are_poison(self):
        self.assertTrue(is_poison_ip("157.240.8.41"))
        self.assertTrue(is_poison_ip("162.125.32.9"))

    def test_hetzner_kryptex_is_not_poison(self):
        self.assertFalse(is_poison_ip("157.90.2.22"))

    def test_poison_ip_classifies_poison_even_if_tcp_fast(self):
        self.assertEqual(classify_half("108.160.166.142", 80), "POISON")

    def test_slow_tcp_on_unknown_ip_is_intercept(self):
        self.assertEqual(classify_half("203.0.113.10", 3500), "INTERCEPT")

    def test_fast_tcp_on_real_ip_stays_half(self):
        self.assertEqual(classify_half("157.90.2.22", 80), "HALF")

    def test_all_poison_summary_is_not_missing_coin(self):
        msg = summarize_all_half(["POISON", "POISON", "INTERCEPT"])
        self.assertNotIn("没上这个币", msg)
        self.assertIn("污染", msg)


if __name__ == "__main__":
    unittest.main()
