# Decisions

- 2026-11-07: 只读学习 `/Users/yin/Movies/未命名文件夹` 的多池 URL + failover；根因是 Kryptex KLS 主机 NXDOMAIN，不是防火墙。verify_pool 改为 host:port 端点探测并区分 NXDOMAIN。
