#!/usr/bin/env bash
# 查看挖矿状态：会话 / 进程 / 显卡 / 日志中的算力与份额
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

echo "===== 钱包 ====="
echo "默认：钱包${ACTIVE_WALLET}"
echo "  钱包1 = $WALLET_1"
echo "  钱包2 = $WALLET_2"
echo "矿工：$WORKER    主池：$POOL_PRIMARY"

echo ""
echo "===== screen 会话 ====="
RUN=0
for sess in kaspa-miner kaspa-miner2; do
    SCREEN_LS="$(screen -ls 2>/dev/null || true)"
    if echo "$SCREEN_LS" | grep -q "\.${sess}[[:space:]]"; then
        echo "  ${sess}：运行中"
        RUN=1
    else
        echo "  ${sess}：未运行"
    fi
done

echo ""
echo "===== 进程 ====="
pgrep -af lolMiner || echo "  无 lolMiner 进程"

echo ""
echo "===== 显卡 ====="
if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi --query-gpu=index,name,temperature.gpu,power.draw,utilization.gpu,clocks.mem,clocks.sm --format=csv
else
    echo "  无 nvidia-smi"
fi

echo ""
echo "===== 挖矿输出 ====="
for sess in kaspa-miner kaspa-miner2; do
    LOG="$LOG_DIR/${sess}_current.log"
    if [ -e "$LOG" ]; then
        echo "--- ${sess} ---"
        tail -n 6 "$LOG"
        echo ""
    fi
done

echo "===== 访问入口 ====="
# hostname -I 只在部分发行版存在；多级兜底，别让一个 IP 查询把整个 status 带崩
get_ip() {
    local ip=""
    ip="$(hostname -I 2>/dev/null | awk '{print $1}')" || true
    [ -z "$ip" ] && ip="$(ip -4 route get 1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}' | head -1)" || true
    [ -z "$ip" ] && ip="$(ifconfig 2>/dev/null | awk '/inet /{print $2; exit}')" || true
    echo "${ip:-127.0.0.1}"
}
IP="$(get_ip)"
echo "  统计面板：http://${IP}:${API_PORT}/gui"
echo "  矿池收益：${POOL_WEB} 搜你的 ${POOL_COIN} 地址"
