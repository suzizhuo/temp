#!/usr/bin/env python3
"""RED tests for pool endpoint parsing and NXDOMAIN diagnosis."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from poolprobe import dns_fail_label, parse_targets, summarize_all_bad


class ParseTargetsTest(unittest.TestCase):
    def test_bare_host_uses_default_ports(self):
        self.assertEqual(
            parse_targets("kls.kryptex.network", "7022"),
            [("kls.kryptex.network", 7022)],
        )

    def test_host_port_is_one_endpoint_not_cartesian(self):
        got = parse_targets(
            "kls.2miners.com:2020 karlsen.woolypooly.com:3333", "7022"
        )
        self.assertEqual(
            got,
            [
                ("kls.2miners.com", 2020),
                ("karlsen.woolypooly.com", 3333),
            ],
        )

    def test_stratum_url(self):
        self.assertEqual(
            parse_targets("stratum+tcp://de.karlsen.herominers.com:11450", "3333"),
            [("de.karlsen.herominers.com", 11450)],
        )

    def test_comma_separated_mixed(self):
        got = parse_targets("a.example,b.example:4444", "3333")
        self.assertEqual(got, [("a.example", 3333), ("b.example", 4444)])


class DnsLabelTest(unittest.TestCase):
    def test_linux_errno_minus2_is_nxdomain(self):
        self.assertEqual(
            dns_fail_label(OSError(-2, "Name or service not known")),
            "NXDOMAIN",
        )

    def test_macos_errno_8_is_nxdomain(self):
        self.assertEqual(
            dns_fail_label(OSError(8, "nodename nor servname provided, or not known")),
            "NXDOMAIN",
        )

    def test_all_nxdomain_summary_is_not_firewall(self):
        msg = summarize_all_bad(["NXDOMAIN", "NXDOMAIN"])
        self.assertNotIn("防火墙", msg)
        self.assertIn("域名不存在", msg)


if __name__ == "__main__":
    unittest.main()
