#!/usr/bin/env python3
"""Parse pool endpoints and classify DNS failures for verify_pool.sh."""
from __future__ import annotations

import json
import socket
import time


def parse_targets(hosts, default_ports):
    tokens = []
    for chunk in str(hosts or "").replace(",", " ").split():
        if chunk:
            tokens.append(chunk)
    ports = []
    for chunk in str(default_ports or "").replace(",", " ").split():
        if chunk:
            ports.append(int(chunk))
    if not ports:
        ports = [3333]

    out = []
    seen = set()
    for raw in tokens:
        host, port = _split_endpoint(raw)
        if port is not None:
            item = (host, port)
            if item not in seen:
                seen.add(item)
                out.append(item)
            continue
        for p in ports:
            item = (host, p)
            if item not in seen:
                seen.add(item)
                out.append(item)
    return out


def _split_endpoint(raw):
    u = str(raw).strip()
    for prefix in ("stratum+tcp://", "stratum+ssl://", "stratum://", "tcp://"):
        if u.lower().startswith(prefix):
            u = u[len(prefix) :]
            break
    if u.startswith("[") and "]" in u:
        host, rest = u[1:].split("]", 1)
        if rest.startswith(":") and rest[1:].isdigit():
            return host, int(rest[1:])
        return host, None
    if ":" in u:
        host, maybe_port = u.rsplit(":", 1)
        if maybe_port.isdigit() and host:
            return host, int(maybe_port)
    return u, None


def dns_fail_label(exc):
    errno = getattr(exc, "errno", None)
    msg = str(exc).lower()
    if errno in (-2, 8, socket.EAI_NONAME):
        return "NXDOMAIN"
    needles = (
        "name or service not known",
        "nodename nor servname",
        "not known",
        "nxdomain",
    )
    if any(n in msg for n in needles):
        return "NXDOMAIN"
    return "OTHER"


def summarize_all_bad(labels):
    labels = list(labels or [])
    if labels and all(x == "NXDOMAIN" for x in labels):
        return (
            "域名不存在（NXDOMAIN）：主机名已从公共 DNS 删除。"
            "Kryptex 已下架 KLS。把 POOL_TRY_HOSTS 改成 host:port 列表后重试。"
        )
    return "检查 DNS、防火墙、外网出口"


def probe_one(host, port, timeout=4):
    t0 = time.time()
    try:
        ip = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)[0][4][0]
    except Exception as e:
        return "BAD", f"DNS 解析失败：{e}", dns_fail_label(e)
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
    except Exception as e:
        rtt = int((time.time() - t0) * 1000)
        return "BAD", f"TCP 不通（{rtt}ms）：{type(e).__name__}", "TCP"
    try:
        s.settimeout(timeout)
        s.sendall(
            (
                json.dumps(
                    {"id": 1, "method": "mining.subscribe", "params": ["poolprobe/1.0"]}
                )
                + "\n"
            ).encode()
        )
        data = s.recv(2048)
    except Exception:
        rtt = int((time.time() - t0) * 1000)
        return (
            "HALF",
            f"TCP 通（{ip} {rtt}ms）但 stratum 无回应：池子没回话（没上这个币/被拦截/后端挂了）",
            "HALF",
        )
    finally:
        try:
            s.close()
        except Exception:
            pass
    text = data.decode(errors="replace").strip()
    first = text.splitlines()[0] if text else "(空)"
    rtt = int((time.time() - t0) * 1000)
    return "GOOD", f"{rtt}ms  stratum 回应：{first[:100]}", "GOOD"


def main(argv):
    import sys

    if len(argv) < 2:
        sys.stderr.write("usage: poolprobe.py parse|probe|summarize ...\n")
        return 2
    cmd = argv[1]
    if cmd == "parse":
        hosts = argv[2] if len(argv) > 2 else ""
        ports = argv[3] if len(argv) > 3 else ""
        for host, port in parse_targets(hosts, ports):
            sys.stdout.write(f"{host}:{port}\n")
        return 0
    if cmd == "probe":
        host, port, outfile = argv[2], int(argv[3]), argv[4]
        lvl, msg, label = probe_one(host, port)
        with open(outfile, "w") as f:
            f.write(f"{lvl}|{label}|{msg}")
        return 0
    if cmd == "summarize":
        labels = argv[2].split(",") if len(argv) > 2 and argv[2] else []
        sys.stdout.write(summarize_all_bad(labels) + "\n")
        return 0
    sys.stderr.write(f"unknown command: {cmd}\n")
    return 2


if __name__ == "__main__":
    import sys

    raise SystemExit(main(sys.argv))
