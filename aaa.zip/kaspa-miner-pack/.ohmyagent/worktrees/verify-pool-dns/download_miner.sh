#!/usr/bin/env bash
# 下载并校验 lolMiner（版本与 sha256 在 config.sh 中锁定）
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/config.sh"

TAR="$PACK_DIR/lolMiner_v${MINER_VERSION}_Lin64.tar.gz"

# 二进制在但丢了执行位（拷贝/解压丢权限时常见）：补上就好，不用重下
if [ -f "$MINER_BIN" ] && [ ! -x "$MINER_BIN" ]; then
    echo "[*] 发现矿机不可执行，补执行位：$MINER_BIN"
    chmod +x "$MINER_BIN" || true
fi

if [ ! -x "$MINER_BIN" ]; then
    echo "[+] 下载 lolMiner $MINER_VERSION ..."
    curl -fSL --retry 3 --retry-all-errors -o "$TAR" "$MINER_URL"

    echo "[+] 校验 sha256..."
    ACTUAL="$(sha256sum "$TAR" | awk '{print $1}')"
    if [ "$ACTUAL" != "$MINER_SHA256" ]; then
        echo "[!] sha256 不匹配，下载可能损坏："
        echo "    期望 $MINER_SHA256"
        echo "    实际 $ACTUAL"
        rm -f "$TAR"
        exit 1
    fi
    echo "    sha256 OK：$ACTUAL"

    echo "[+] 解压..."
    rm -rf "$PACK_DIR/miner_extract"
    mkdir -p "$PACK_DIR/miner_extract"
    tar -xzf "$TAR" -C "$PACK_DIR/miner_extract"
    rm -rf "$MINER_DIR"
    FOUND="$(find "$PACK_DIR/miner_extract" -maxdepth 2 -type f -name lolMiner | head -1)"
    if [ -z "$FOUND" ]; then
        echo "[!] 压缩包内未找到 lolMiner 可执行文件"
        exit 1
    fi
    mv "$(dirname "$FOUND")" "$MINER_DIR"
    rm -rf "$PACK_DIR/miner_extract"
    chmod +x "$MINER_BIN"
else
    echo "[=] 已存在可用的矿机：$MINER_BIN"
fi

echo "[+] 矿机信息："
"$MINER_BIN" --version 2>&1 | head -5 || true
echo "[OK] $MINER_BIN 就绪"
