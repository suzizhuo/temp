#!/usr/bin/env bash
# 安装 systemd 开机自启服务（与 screen 二选一，不要同时用）
# 用法：
#   sudo ./systemd_install.sh            单实例
#   sudo ./systemd_install.sh --dual     双实例（需 .env 文件配合，见脚本尾部）
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

MODE="${1:-single}"
SERVICE="kaspa-miner"
UNIT="/etc/systemd/system/${SERVICE}.service"
CUR_USER="${SUDO_USER:-$USER}"

echo "[+] 写入 $UNIT ..."
sudo tee "$UNIT" >/dev/null <<EOF
[Unit]
Description=Kaspa Miner (lolMiner / woolypooly)
After=network-online.target nvidia-persistenced.service
Wants=network-online.target

[Service]
Type=simple
User=${CUR_USER}
WorkingDirectory=${PACK_DIR}
EnvironmentFile=${PACK_DIR}/kaspa-miner.env
ExecStart=/bin/bash -c 'exec "${PACK_DIR}/start.sh" ${KASPA_EXTRA_ARGS}'
ExecStop=/bin/bash -c 'exec "${PACK_DIR}/stop.sh"'
Restart=always
RestartSec=10
TimeoutStopSec=30
Environment=HOME=${HOME}

[Install]
WantedBy=multi-user.target
EOF

# 环境文件（单实例默认；双实例把 KASPA_EXTRA_ARGS 改成 --dual）
cat > "$PACK_DIR/kaspa-miner.env" <<EOF
KASPA_EXTRA_ARGS=
EOF
if [ "$MODE" = "--dual" ]; then
    echo "KASPA_EXTRA_ARGS=--dual" > "$PACK_DIR/kaspa-miner.env"
    echo "[+] 已配置双实例模式"
fi

sudo systemctl daemon-reload
sudo systemctl enable "$SERVICE"
sudo systemctl start "$SERVICE"

echo ""
echo "[OK] 服务已安装并启动：$SERVICE"
echo "    状态：sudo systemctl status $SERVICE"
echo "    日志：journalctl -u $SERVICE -f"
echo "    停止：sudo systemctl stop $SERVICE"
echo "    卸载：sudo systemctl disable --now $SERVICE && sudo rm $UNIT ${PACK_DIR}/kaspa-miner.env && sudo systemctl daemon-reload"
echo ""
echo "    注意：systemd 模式下不要再开 screen；screen 模式不要再启动本服务。"
