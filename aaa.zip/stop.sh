#!/usr/bin/env bash
# 停止挖矿（保留超频设置，重启后持久化设置失效属正常，重跑 oc_tune.sh 即可）
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

STOPPED=0
for sess in kaspa-miner kaspa-miner2; do
    SCREEN_LS="$(screen -ls 2>/dev/null || true)"
    if echo "$SCREEN_LS" | grep -q "\.${sess}[[:space:]]"; then
        screen -S "$sess" -X quit
        echo "[+] screen 会话 ${sess} 已关闭"
        STOPPED=1
    fi
done

sleep 1
if pkill -f "lolMiner" 2>/dev/null; then
    echo "[+] lolMiner 进程已结束"
    STOPPED=1
fi

[ "$STOPPED" = "1" ] || echo "[-] 没有发现运行中的挖矿进程"
echo "[OK] 已停止。"
