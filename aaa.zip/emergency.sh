#!/usr/bin/env bash
# lolMiner --watchdog script 模式的外部脚本（备选守护方式）
# 默认配置用 --watchdog exit + run_instance.sh 守护循环，本脚本仅为完整性保留：
# 若 config.sh 的 WATCHDOG_MODE 改为 script，矿机崩溃时会调用本脚本然后自行退出。
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[$(date '+%F %T')] emergency.sh 被 lolMiner 触发（GPU/驱动异常）"
# 记录现场后由守护进程重启；如需重启整机可取消下一行注释
# sync && sudo reboot
exit 0
