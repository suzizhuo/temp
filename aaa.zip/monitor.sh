#!/usr/bin/env bash
# 实时监控（5 秒刷新）：显卡 + 矿机输出。Ctrl+C 退出
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

trap 'echo; echo "[*] 监控退出"; exit 0' INT
echo "按 Ctrl+C 退出监控..."
sleep 1

while true; do
    clear
    echo "=============== Kaspa 满血监控 $(date '+%F %T') ==============="
    echo "钱包：钱包${ACTIVE_WALLET}(${KASPA_WALLET_1:0:20}...)  矿工：${WORKER}  主池：${POOL_PRIMARY}"
    echo "-------------------------------------------------------------"
    if command -v nvidia-smi >/dev/null 2>&1; then
        nvidia-smi --query-gpu=index,name,temperature.gpu,power.draw,utilization.gpu,clocks.mem,clocks.sm,fan.speed --format=csv
    fi
    echo "-------------------------------------------------------------"
    for sess in kaspa-miner kaspa-miner2; do
        LOG="$LOG_DIR/${sess}_current.log"
        [ -e "$LOG" ] || continue
        echo "[${sess}]"
        grep -E "Total Speed|Accepted|Rejected|New job|Connected|Pool" "$LOG" 2>/dev/null | tail -n 3
        tail -n 3 "$LOG"
    done
    echo "============================================================="
    sleep 5
done
