#!/usr/bin/env bash
# 系统内存满血调优（配合 oc_tune.sh 使用）：
#   大页预留、降低 swappiness、THP 策略、可选 swapoff。
# 用法：
#   sudo ./mem_tune.sh              按 config.sh 应用
#   sudo ./mem_tune.sh reset        恢复 swappiness 与 THP（大页不自动回收，避免分配失败）
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

[ "$(id -u)" -eq 0 ] || { echo "[!] 需 root 权限调优内存（sudo ./mem_tune.sh）"; exit 1; }

MODE="${1:-apply}"

if [ "$MODE" = "reset" ]; then
    echo "[+] 恢复 swappiness/THP 默认值..."
    sysctl -w vm.swappiness=60 >/dev/null 2>&1 || true
    for f in /sys/kernel/mm/transparent_hugepage/enabled; do
        [ -w "$f" ] && echo always > "$f" 2>/dev/null || true
    done
    echo "[OK] 已恢复。"
    exit 0
fi

[ "$MEM_TUNE" = "1" ] || { echo "[=] MEM_TUNE=0，跳过内存调优"; exit 0; }

echo "[+] 应用内存满血调优..."

# 交换倾向：越小越不爱换出，挖矿进程尽量留在物理内存
sysctl -w vm.swappiness="$SWAPPINESS" >/dev/null && echo "  vm.swappiness -> $SWAPPINESS" || echo "  [!] 写 vm.swappiness 失败"

# 回收页缓存的压力：调小，减少内核回收活跃页
sysctl -w vm.vfs_cache_pressure=50 >/dev/null 2>&1 && echo "  vm.vfs_cache_pressure -> 50" || true

# 大页预留（2MiB/页），给 kHeavyHash 数据集与矿机进程锁内存，避免碎片化分配掉算力
before="$(awk '/^HugePages_Total:/{print $2; exit}' /proc/meminfo 2>/dev/null || echo 0)"
if sysctl -w vm.nr_hugepages="$HUGEPAGES" >/dev/null 2>&1 || echo "$HUGEPAGES" > /proc/sys/vm/nr_hugepages 2>/dev/null; then
    got="$before"
    for _ in $(seq 1 10); do
        got="$(awk '/^HugePages_Total:/{print $2; exit}' /proc/meminfo 2>/dev/null || echo 0)"
        [ "$got" -ge "$HUGEPAGES" ] && break
        sleep 1
    done
    echo "  vm.nr_hugepages -> $before -> $got (目标 $HUGEPAGES，约 $((HUGEPAGES*2))MiB)"
else
    echo "  [!] 无法设置 nr_hugepages（容器/权限受限可跳过）"
fi

# Transparent Huge Pages
for f in /sys/kernel/mm/transparent_hugepage/enabled; do
    if [ -w "$f" ]; then
        b="$(cat "$f")"
        echo "$THP_MODE" > "$f" 2>/dev/null && echo "  THP $b -> $(cat "$f")" || echo "  [!] 写 $f 失败"
    fi
done

# 交换分区：彻底关掉（掉进 swap 就掉算力），默认不开，确认无 OOM 风险后改 SWAPOFF=1
if [ "$SWAPOFF" = "1" ]; then
    swapoff -a && echo "  swapoff -a 已执行" || echo "  [!] swapoff -a 失败"
else
    echo "  [=] swap 保持不动（SWAPOFF=0）；如需彻底关：改 config.sh SWAPOFF=1 后重跑"
fi

echo ""
echo "[+] 当前内存概览："
awk '/^MemTotal:|^MemAvailable:|^HugePages_Total:|^HugePages_Free:|^SwapTotal:/{print "  "$0}' /proc/meminfo
echo "[OK] 内存调优完成（重启后失效，重跑本脚本即可）。"
