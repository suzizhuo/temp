#!/usr/bin/env bash
set -uo pipefail
# Run on the Mac. Cloud miner then connects to 127.0.0.1:1010.
# 极速默认: IPQoS=lowdelay 打低延迟标记 / 5s 保活探测死链 / autossh 5s 轮询 / 断线 2s 重连。
# (云机能直连池时 start.sh 已经不走这里, 这是兜底通道。)
MINER_HOST="${MINER_HOST:-8.155.86.169}"
MINER_PORT="${MINER_PORT:-53205}"
POOL_HOST="${POOL_HOST:-141.95.124.89}"
POOL_PORT="${POOL_PORT:-1010}"

ssh_common=(
  -o ServerAliveInterval=5
  -o ServerAliveCountMax=3
  -o ExitOnForwardFailure=yes
  -o ConnectTimeout=5
  -o TCPKeepAlive=yes
  -o IPQoS=lowdelay          # DiffServ 低延迟标记, 中间设备分段排队优先
  -o Compression=no          # stratum 小包, 压缩纯赔延迟
)

if command -v autossh >/dev/null 2>&1; then
  export AUTOSSH_GATETIME=0
  export AUTOSSH_POLL=5       # 5s 一次健康检查, 死链立刻换隧道
  exec autossh -M 0 -N "${ssh_common[@]}" \
    -R "127.0.0.1:${POOL_PORT}:${POOL_HOST}:${POOL_PORT}" \
    -p "$MINER_PORT" "root@${MINER_HOST}"
fi

# 无 autossh: 自杀式重连循环
while true; do
  echo "$(date '+%F %T') relay: connecting root@${MINER_HOST}:${MINER_PORT}" >&2
  ssh -N "${ssh_common[@]}" \
    -R "127.0.0.1:${POOL_PORT}:${POOL_HOST}:${POOL_PORT}" \
    -p "$MINER_PORT" "root@${MINER_HOST}"
  echo "$(date '+%F %T') relay: ssh exited ($?), 2s 后重连" >&2
  sleep 2
done
