#!/usr/bin/env bash
# ETC / etchash 榨干 + 极速版启动器 (cloud side, T-Rex 0.26.8)
# 所有加压项均可用环境变量覆盖; 空值 = 不传该参数。
# 极速默认已写死: INTENSITY=25 / DAG_EPOCH=-1 / LHR=full / DAG_BUILD=2 / 池 TCP 可达自动直连 (少走 Mac 中转一跳)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
export LD_LIBRARY_PATH="$ROOT/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
mkdir -p logs

# 内存锁定上限拉满 + GPU 持久化模式 (幂等, 失败不阻塞启动)
ulimit -l unlimited 2>/dev/null || true
command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi -pm 1 >/dev/null 2>&1 || true

POOL_HOST="${POOL_HOST:-141.95.124.89}"
POOL_PORT="${POOL_PORT:-1010}"
POOL="${POOL:-stratum+tcp://127.0.0.1:1010}"
WALLET="${WALLET:-0x39736333b8710cda6b4bd48273282b7da21ffb9c}"
WORKER="${WORKER:-$(hostname -s 2>/dev/null || echo rig)}"

# ---- 极速: 池 TCP 可达就直接 stratum 直连, 少走 "cloud<->Mac" 中转这一跳 ----
# 不可达自动回落到本地中转 (relay.sh 反向隧道)。强制走中转: POOL_DIRECT=0
POOL_DIRECT="${POOL_DIRECT:-1}"
if [ "$POOL_DIRECT" = "1" ]; then
  probe=0
  if command -v timeout >/dev/null 2>&1; then
    timeout 3 bash -c "exec 3<>/dev/tcp/${POOL_HOST}/${POOL_PORT}" 2>/dev/null && probe=1 || probe=0
  elif command -v nc >/dev/null 2>&1; then
    nc -z -G 3 "$POOL_HOST" "$POOL_PORT" >/dev/null 2>&1 && probe=1 || probe=0
  fi
  if [ "$probe" = "1" ]; then
    POOL="stratum+tcp://${POOL_HOST}:${POOL_PORT}"
    echo "pool direct ok -> $POOL (跳过 Mac 中转, 延迟最低)"
  else
    echo "pool 直连不通, 回落中转 -> $POOL"
  fi
fi

# ---- 算力压榨 (GPU), 默认全部写死 ----
INTENSITY="${INTENSITY:-25}"         # 8-25 榨干档; 不稳回退: INTENSITY=22
KERNEL="${KERNEL:-0}"                # 0=默认; 固定某卡可锁 1-5
LHR_TUNE="${LHR_TUNE:-}"             # 固定 LHR 百分比 (如 77.5); 留空 = autotune 全自动探顶
LHR_MODE="${LHR_MODE:-full}"         # off | down | full (full=双向探顶)
LHR_STEP="${LHR_STEP:-0.5}"
LHR_INTERVAL="${LHR_INTERVAL:-1:10}" # 每 N:MAX 分钟一调
LHR_LOW_POWER="${LHR_LOW_POWER:-0}"  # 0=不降功耗, 保算力
TEMP_LIMIT="${TEMP_LIMIT:-93}"       # 核心温度硬顶 (关机)
TEMP_START="${TEMP_START:-80}"       # 降到多少再恢复
CPU_PRIORITY="${CPU_PRIORITY:-5}"    # 进程优先级拉满
FAN="${FAN:-}"                       # 空=不控风扇; "t:75"=核心目标温度自动转速; "85"=固定85%
DAG_EPOCH="${DAG_EPOCH:--1}"         # 预生成下一纪元 DAG: 吃满显存 + 切纪元不掉算力

# ---- 显存/内存压榨 (可选, 按卡能力填) ----
CORE_OFFSET="${CORE_OFFSET:-}"       # --cclock MHz 核心超频
MEM_OFFSET="${MEM_OFFSET:-}"         # --mclock MHz 显存超频
POWER_LIMIT="${POWER_LIMIT:-}"       # --pl 瓦数上限 (Linux 单位: W)
LOCK_CCLOCK="${LOCK_CCLOCK:-}"       # --lock-cclock MHz 锁定核心频率, 掉 P0 不掉速
NONCE_RANGE="${NONCE_RANGE:-}"       # 多卡切分范围, 默认自动
DAG_BUILD="${DAG_BUILD:-2}"          # 多卡时 DAG 多流并发构建 2 (单卡无感)

args=(
  -a etchash
  --coin etc
  -i "$INTENSITY"
  --kernel "$KERNEL"
  --lhr-autotune-mode "$LHR_MODE"
  --lhr-autotune-step-size "$LHR_STEP"
  --lhr-autotune-interval "$LHR_INTERVAL"
  --lhr-low-power "$LHR_LOW_POWER"
  --temperature-limit "$TEMP_LIMIT"
  --temperature-start "$TEMP_START"
  --cpu-priority "$CPU_PRIORITY"
  --extra-dag-epoch "$DAG_EPOCH"
  --no-watchdog                       # 内置看护关掉, 换外部看护闭环
  --api-bind-http "127.0.0.1:${API_PORT:-4067}"
  --no-color
  --log-path "logs/t-rex.log"
  -o "$POOL"
  -u "$WALLET"
  -p "${PASSWORD:-x}"
  -w "$WORKER"
)

add_if_set() {
  if [ -n "$2" ]; then args+=("$1" "$2"); fi
  return 0
}
add_if_set "--lhr-tune"      "$LHR_TUNE"
add_if_set "--fan"           "$FAN"
add_if_set "--cclock"        "$CORE_OFFSET"
add_if_set "--mclock"        "$MEM_OFFSET"
add_if_set "--pl"            "$POWER_LIMIT"
add_if_set "--lock-cclock"   "$LOCK_CCLOCK"
add_if_set "--nonce-range-size" "$NONCE_RANGE"
add_if_set "--dag-build-mode"   "$DAG_BUILD"

if [ "${DRY_RUN:-0}" = "1" ]; then
  printf '%q ' "$ROOT/bin/t-rex" "${args[@]}"; echo
  exit 0
fi

exec "$ROOT/bin/t-rex" "${args[@]}"
