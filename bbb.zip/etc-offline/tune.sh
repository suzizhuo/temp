#!/usr/bin/env bash
# tune.sh - 云机端 host/GPU/内存 调优 (root 运行, 幂等, 可反复跑)
# 目标: 榨干 GPU (锁频/超频/ECC/MIG/温控) + 内存自动拉满 (swap 清场/sysctl/thp/ballast/hugepages)
# 默认全部写死, 需要收敛用环境变量: MEM_FLOOR_GB / BALLAST_PCT / BALLAST_MIN_TOTAL_GB /
#   SYSCTL_FILE / PL_WATT / LOCK_CORE / CLOCK_TWEAK / ECC_OFF
set -uo pipefail

step() { printf '\n== %s ==\n' "$*"; }

# ---- 1. 纪元 / DAG / 内存预算 ----
step "纪元 / DAG / 内存预算"
# 优先级: 1) t-rex 日志真实 epoch  2) 时间估算 (30000 块/纪元, ~13s/块)
NOW_TS="$(date +%s)"
LOG_EPOCH=$(grep -aoiE 'epoch[ (:]*[0-9]+' "$PWD/logs/t-rex.log" 2>/dev/null | tail -n1 | grep -oE '[0-9]+$')
if [ -n "${LOG_EPOCH:-}" ]; then
  EPOCH="$LOG_EPOCH"; SRC="log"
else
  EPOCH=$(( (NOW_TS - 1438269973) / 390000 + 1 )); SRC="estimate"
fi
DAG_BYTES=$(( 1073741824 + 8388608 * EPOCH ))
DAG_GB=$(awk -v b="$DAG_BYTES" 'BEGIN{printf "%.2f", b/1073741824}')
RAM_GB=$(awk '/MemTotal/{printf "%.1f",$2/1048576}' /proc/meminfo 2>/dev/null)
AVAIL_GB=$(awk '/MemAvailable/{printf "%.1f",$2/1048576}' /proc/meminfo 2>/dev/null)
RAM_GB="${RAM_GB:-?}"; AVAIL_GB="${AVAIL_GB:-?}"
MIN_NEED=$(awk -v b="$DAG_BYTES" 'BEGIN{printf "%.1f", 4*b/1073741824}')
echo "epoch ~ $EPOCH ($SRC)   DAG ~ ${DAG_GB} GiB   (构建缓冲2x + 预生成下一纪元1x + 系统1x)"
echo "MemTotal=${RAM_GB} GiB   MemAvailable=${AVAIL_GB} GiB   建议 >= ${MIN_NEED} GiB"
awk -v a="$RAM_GB" -v m="$MIN_NEED" 'BEGIN{exit !(a<m)}' 2>/dev/null \
  && echo "[warn] 内存偏紧: 调低 INTENSITY, 或 DAG_EPOCH 置空, 或加 RAM 再挖" || true

# ---- 2. 内存自动拉满 ----
step "内存自动拉满"
FLOOR_GB="${MEM_FLOOR_GB:-4}"                    # 永远不动的系统/矿工余量 (GiB)
BALLAST_PCT="${BALLAST_PCT:-85}"                 # ballast 目标 = (可用 - 保底) * 该百分比
BALLAST_MIN_TOTAL_GB="${BALLAST_MIN_TOTAL_GB:-16}"  # 小于该内存不开 ballast; 置 0 强开
TOTAL_KB=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null)
AVAIL_KB=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null)
FLOOR_KB=$((FLOOR_GB * 1048576))
TOTAL_GB=$(awk -v k="${TOTAL_KB:-0}" 'BEGIN{printf "%.1f", k/1048576}')
AVAIL_GB=$(awk -v k="${AVAIL_KB:-0}" 'BEGIN{printf "%.1f", k/1048576}')
echo "MemTotal=${TOTAL_GB}G  MemAvailable=${AVAIL_GB}G  保底=${FLOOR_GB}G  (ballast 阈值 ${BALLAST_MIN_TOTAL_GB}G)"

# 2.1 swap 彻底清场 + fstab 勾掉 (留备份, 幂等) + zram 停 + swap.target 屏蔽
step "swap / zram 清场"
if swapoff -a 2>/dev/null; then echo "swapoff ok"; else echo "swapoff 跳过(已是 no-swap 或无权限)"; fi
if [ -f /etc/fstab ] && grep -qE '^[^#]+[[:space:]]+(swap|none)[[:space:]]+swap' /etc/fstab 2>/dev/null; then
  if [ ! -f /etc/fstab.pre-turbo ]; then
    cp -a /etc/fstab /etc/fstab.pre-turbo 2>/dev/null && echo "fstab 备份 -> /etc/fstab.pre-turbo"
  fi
  if awk '{ if ($0 !~ /^[[:space:]]*#/ && ($2 == "swap" || $3 == "swap")) print "# turbo-disabled " $0; else print $0 }' /etc/fstab > /etc/fstab.turbo-tmp 2>/dev/null; then
    cat /etc/fstab.turbo-tmp > /etc/fstab 2>/dev/null || cp -a /etc/fstab.turbo-tmp /etc/fstab 2>/dev/null
    rm -f /etc/fstab.turbo-tmp
    echo "fstab swap 行已注释 (回滚: cp -a /etc/fstab.pre-turbo /etc/fstab)"
  else
    echo "fstab 改写失败, 保留原样"
  fi
else
  echo "fstab 无 swap 行 (或不可读)"
fi
if command -v systemctl >/dev/null 2>&1; then
  systemctl mask swap.target >/dev/null 2>&1 && echo "swap.target masked" || true
  systemctl stop zramswap >/dev/null 2>&1 || true
  systemctl stop 'zramswap@*' >/dev/null 2>&1 || true
fi

# 2.2 sysctl 低延迟 / 内存策略 -> 持久化 /etc/sysctl.d/99-turbo.conf (重启仍生效)
step "sysctl (持久化 + 即时生效)"
SYSCTL_FILE="${SYSCTL_FILE:-/etc/sysctl.d/99-turbo.conf}"
MINFREE_KB=$((262144 * FLOOR_GB))     # 保底越多留的 min_free 越多 (4G 保底 -> 1GiB)
set_kv() { # key value
  printf '%s = %s\n' "$1" "$2" >> "$SYSCTL_FILE" 2>/dev/null || true
  local path; path="/proc/sys/$(printf '%s' "$1" | tr '.' '/')"
  if [ -w "$path" ]; then
    echo "$2" > "$path" 2>/dev/null && echo "  $1 = $2" || echo "  $1 写入失败"
  else
    echo "  $1 跳过(路径不存在或无权限)"
  fi
}
if { [ -w "$SYSCTL_FILE" ] || [ -w "$(dirname "$SYSCTL_FILE")" ]; } 2>/dev/null; then
  : > "$SYSCTL_FILE" 2>/dev/null || true
  set_kv vm.swappiness 1
  set_kv vm.vfs_cache_pressure 50
  set_kv vm.page-cluster 0               # 关读聚合, 随机读延迟直下
  set_kv vm.dirty_background_ratio 5
  set_kv vm.dirty_ratio 15
  set_kv vm.dirty_expire_centisecs 300
  set_kv vm.dirty_writeback_centisecs 100
  set_kv vm.min_free_kbytes "$MINFREE_KB"
  set_kv vm.overcommit_memory 1
  set_kv net.ipv4.tcp_notsent_lowat 16384  # 限未发送队列深度, stratum 小包延迟直下
  set_kv net.ipv4.tcp_tw_reuse 1
  set_kv net.ipv4.tcp_fastopen 3
  set_kv net.ipv4.tcp_keepalive_time 15
  set_kv net.ipv4.tcp_keepalive_intvl 5
  set_kv net.ipv4.tcp_keepalive_probes 3
  echo "写入 $SYSCTL_FILE (回滚: rm $SYSCTL_FILE)"
else
  echo "无写权限 (非 root), 跳过 sysctl"
fi

# 2.3 THP + governor performance + 锁 CPU 最高频
step "THP / CPU governor"
if echo always > /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null; then echo "THP enabled=always ok"; else echo "THP enabled 跳过"; fi
echo madvise > /sys/kernel/mm/transparent_hugepage/defrag 2>/dev/null || true
# 空 glob 未展开时兜底, 非 Linux 不刷错误
shopt -s nullglob 2>/dev/null || true
for CPUF in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  [ -w "$CPUF" ] && echo performance > "$CPUF" 2>/dev/null
done
for CPUF in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do
  [ -w "$CPUF" ] || continue
  BASE="${CPUF%/scaling_min_freq}"
  MAXF="$(cat "$BASE/scaling_max_freq" 2>/dev/null)"
  [ -n "${MAXF:-}" ] && echo "$MAXF" > "$CPUF" 2>/dev/null
done
echo "governor=performance, scaling_min->max 已锁最高频 (guest 层 best-effort)"

# 2.4 自动拉满: tmpfs ballast + hugepages (只增不减, 保底 FLOOR_GB 不动)
step "自动拉满 (ballast + hugepages)"
BALLAST=/dev/shm/turbo-ballast
cur_hp=$(cat /proc/sys/vm/nr_hugepages 2>/dev/null || echo 0)
HP_KB=$(awk '/^Hugepagesize/{print $2}' /proc/meminfo 2>/dev/null | head -n1)
HP_KB="${HP_KB:-2048}"
BALLAST_KB=0
if [ "${TOTAL_KB:-0}" -ge $((BALLAST_MIN_TOTAL_GB * 1048576)) ] && [ "${AVAIL_KB:-0}" -gt $((FLOOR_KB + 1048576)) ]; then
  TARGET_KB=$(( (AVAIL_KB - FLOOR_KB) * BALLAST_PCT / 100 ))
  TARGET_KB=$((TARGET_KB / 1024 * 1024))          # 对齐 MiB
  EXIST_KB=0
  if [ -f "$BALLAST" ]; then
    EXIST_B=$(stat -c%s "$BALLAST" 2>/dev/null || stat -f%z "$BALLAST" 2>/dev/null || echo 0)
    EXIST_KB=$((EXIST_B / 1024))
  fi
  if [ "$TARGET_KB" -gt 0 ] && { [ "$EXIST_KB" -ge "$TARGET_KB" ] || dd if=/dev/zero of="$BALLAST" bs=1024 count="$TARGET_KB" status=none 2>/dev/null; }; then
    BALLAST_KB=$TARGET_KB
    echo "ballast $BALLAST ${BALLAST_KB}KB = $(awk -v k="$BALLAST_KB" 'BEGIN{printf "%.1f", k/1048576}')GiB (可用-保底)*${BALLAST_PCT}%"
  else
    echo "ballast 写失败 (/dev/shm 不可用), 跳过"
  fi
  # 填完复核, 余量跌破保底就割 ballast, OOM 不背锅
  for _ in 1 2 3; do
    AVAIL_KB=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null)
    [ "${AVAIL_KB:-0}" -ge "$FLOOR_KB" ] && break
    BALLAST_KB=$((BALLAST_KB / 2))
    if [ "$BALLAST_KB" -le 512 ]; then rm -f "$BALLAST" 2>/dev/null; BALLAST_KB=0; break; fi
    truncate -s "${BALLAST_KB}K" "$BALLAST" 2>/dev/null || true
    echo "保底不足, ballast 缩到 ${BALLAST_KB}KB"
  done
else
  echo "ballast 跳过 (MemTotal < ${BALLAST_MIN_TOTAL_GB}G, 或余量已近保底; BALLAST_MIN_TOTAL_GB=0 强开)"
fi
# hugepages: 把剩余余量 (可用 - 保底) 一次锁成大页, 逼 hypervisor 交足物理内存
AVAIL_KB=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null)
if [ "${AVAIL_KB:-0}" -gt $((FLOOR_KB + HP_KB * 1024)) ]; then
  WANT_HP=$(( (AVAIL_KB - FLOOR_KB) / HP_KB ))
  if [ "$WANT_HP" -gt "${cur_hp:-0}" ] && { echo "$WANT_HP" > /proc/sys/vm/nr_hugepages 2>/dev/null; }; then
    echo "hugepages ${cur_hp} -> ${WANT_HP} x ${HP_KB}KB (锁 $((WANT_HP * HP_KB / 1048576))GiB)"
  else
    echo "hugepages 跳过 (当前 ${cur_hp}, 只增不减; 或无权限)"
  fi
fi
command -v free >/dev/null 2>&1 && free -h
echo "拉满完成, 保底 ${FLOOR_GB}G 未动"
echo "回滚: rm -f $BALLAST && echo 0 > /proc/sys/vm/nr_hugepages && rm -f $SYSCTL_FILE && cp -a /etc/fstab.pre-turbo /etc/fstab"

# ---- 3. GPU 榨干 ----
step "nvidia-smi 信息"
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "无 nvidia-smi, 跳过驱动层"
else
  nvidia-smi --query-gpu=index,name,pstate,temperature.gpu,power.draw,power.limit,memory.total,memory.used,utilization.gpu,clocks.sm,clocks.mem \
    --format=csv,noheader,nounits | awk -F', *' '{
      printf "GPU%s %s p%s %sC %s/%sW MEM %s/%sMiB UTIL %s%% SM %sMHz MEM %sMHz\n",$1,$2,$3,$4,$5,$6,$8,$7,$9,$10,$11
    }'

  step "Persistence / ECC / MIG"
  nvidia-smi -pm 1 >/dev/null 2>&1 && echo "pm=1 ok" || echo "pm 失败"
  if [ "${ECC_OFF:-0}" = "1" ]; then
    nvidia-smi -e 0 >/dev/null 2>&1 && echo "ECC off 已发令 (重启生效)" || echo "ECC off 被拒"
  else
    echo "ECC 保持 (要关: ECC_OFF=1 $0)"
  fi
  nvidia-smi -mig 0 >/dev/null 2>&1 && echo "MIG off ok" || echo "MIG off 跳过(不支持或已关)"

  step "自动锁顶 (best-effort)"
  MAXSM=$(nvidia-smi --query-gpu=clocks.max.sm --format=csv,noheader,nounits 2>/dev/null | head -n1 | tr -d ' ')
  MAXMEM=$(nvidia-smi --query-gpu=clocks.max.memory --format=csv,noheader,nounits 2>/dev/null | head -n1 | tr -d ' ')
  if [ -n "${MAXSM:-}" ] && [ -n "${MAXMEM:-}" ] && nvidia-smi -ac "${MAXSM},${MAXMEM}" >/dev/null 2>&1; then
    echo "auto -ac ${MAXSM},${MAXMEM} ok (全卡最高频)"
  else
    echo "auto -ac 被拒 (云卡常封顶) -> 兜底走 start.sh 的 CORE_OFFSET/MEM_OFFSET/LOCK_CCLOCK"
  fi

  step "功耗 / 锁频"
  if [ "${PL_WATT:-0}" != "0" ] && nvidia-smi -pl "$PL_WATT" >/dev/null 2>&1; then
    echo "power-limit -> ${PL_WATT}W ok"
  else
    echo "power-limit 跳过 (未设 PL_WATT 或厂商封顶; 兜底用 start.sh 的 POWER_LIMIT)"
  fi
  if [ -n "${LOCK_CORE:-}" ]; then
    nvidia-smi -lgc "$LOCK_CORE" >/dev/null 2>&1 && echo "lock core -> $LOCK_CORE ok" \
      || echo "lock core 被拒 -> 改用 start.sh 的 LOCK_CCLOCK(由 T-Rex 锁)"
  else
    echo "LOCK_CORE 未设, 跳过 (形如 LOCK_CORE=1500,1500)"
  fi
  if [ -n "${CLOCK_TWEAK:-}" ]; then
    nvidia-smi -ac "$CLOCK_TWEAK" >/dev/null 2>&1 && echo "clock tweak -> $CLOCK_TWEAK ok" \
      || echo "clock tweak 被拒 (云卡常封顶; 兜底用 start.sh 的 CORE_OFFSET/MEM_OFFSET)"
  else
    echo "CLOCK_TWEAK 未设, 跳过 (形如 CLOCK_TWEAK=10401,2400)"
  fi
fi

step "完成"
echo "回卷: /proc/sys 改动重启失效; -pm/-lgc 保持至驱动重启; ECC 关掉后如需回退: nvidia-smi -e 1 并重启"
echo "极速组件已写死: start.sh (INTENSITY=25/池直连) · watchdog (15s/2 strike) · relay.sh (IPQoS lowdelay)"
