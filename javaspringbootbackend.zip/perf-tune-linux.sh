#!/usr/bin/env bash
# perf-tune-linux.sh — 挖矿前系统调优：governor、hugepages、THP。
# 幂等，可重复运行；只动与随机数挖矿相关的旋钮，默认安全模式。
set -uo pipefail

HUGE_DEFAULT=1280          # 1280 × 2MiB = 2.5GiB，覆盖 RandomX fast 数据集
HUGE="${HUGE:-$HUGE_DEFAULT}"
AGGRESSIVE=0
failures=0

usage() {
  cat <<'EOF'
Usage: perf-tune-linux.sh [--hugepages N] [--aggressive] [--help]

Default (safe):
  * cpufreq governor -> performance (cpupower 或直接写 sysfs)
  * vm.nr_hugepages 预留 2.5GiB (可用 --hugepages N 覆盖; 可用内存不足时拒绝)
  * THP -> madvise (随机数不用 anonymous THP，madvise 更稳)

--aggressive (额外, 全部只打建议不执行):
  * 停桌面/索引类服务, swap off — 需要自行确认后手动执行

Environment:
  HUGE=N  覆盖 hugepages 页数 (同 --hugepages N)
EOF
}

log()  { printf '%s\n' "$*"; }
step() { printf '\n== %s ==\n' "$*"; }
warn() { printf '[warn] %s\n' "$*" >&2; failures=$((failures+1)); }

while [ $# -gt 0 ]; do
  case "$1" in
    --hugepages) HUGE="${2:-}"; shift 2 ;;
    --hugepages=*) HUGE="${1#*=}"; shift ;;
    --aggressive) AGGRESSIVE=1; shift ;;
    --help|-h) usage; exit 0 ;;
    *) echo "unknown arg: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "must run as root (try: sudo $0 $*)" >&2
  exit 1
fi

if [ "$(uname -s)" != "Linux" ]; then
  warn "not a Linux box; only --help and dry-run expectations apply"
  exit 1
fi

mem_available_kb() { awk '/^MemAvailable:/{print $2; exit}' /proc/meminfo; }

# ---- governor ----
step "cpufreq governor -> performance"
before="$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo unknown)"
if command -v cpupower >/dev/null 2>&1; then
  cpupower frequency-set -g performance >/dev/null 2>&1 || warn "cpupower frequency-set failed"
else
  n=0; ok=0
  for g in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do
    [ -w "$g" ] || continue
    n=$((n+1))
    echo performance > "$g" 2>/dev/null && ok=$((ok+1))
  done
  [ "$n" -gt 0 ] || warn "no writable cpufreq sysfs (intel_pstate/amd-pstate absent or container?)"
  [ "$ok" -eq "$n" ] || warn "governor set on $ok/$n cpus"
fi
after="$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo unknown)"
log "governor: $before -> $after (cpu0)"

# ---- hugepages ----
step "vm.nr_hugepages -> $HUGE (×2MiB = $((HUGE*2))MiB)"
avail_kb="$(mem_available_kb)"
threshold_kb=$((2560*1024))
if [ -n "$avail_kb" ] && [ "$avail_kb" -lt "$threshold_kb" ]; then
  warn "MemAvailable ${avail_kb}kB < 2560MB xmrig-fast floor; 预留前先释放内存 (skip hugepages)"
else
  before="$(cat /proc/sys/vm/nr_hugepages 2>/dev/null || echo unknown)"
  if sysctl -w vm.nr_hugepages="$HUGE" >/dev/null 2>&1; then
    :
  elif [ -w /proc/sys/vm/nr_hugepages ]; then
    echo "$HUGE" > /proc/sys/vm/nr_hugepages 2>/dev/null || warn "write /proc/sys/vm/nr_hugepages failed"
  else
    warn "cannot set nr_hugepages (no sysctl, no /proc write)"
  fi
  # 内核按需合并，等最多 5s 让预留生效
  for _ in 1 2 3 4 5; do
    got="$(awk '/^HugePages_Total:/{print $2; exit}' /proc/meminfo 2>/dev/null || echo 0)"
    [ "${got:-0}" -ge "$HUGE" ] && break
    sleep 1
  done
  after_total="$(awk '/^HugePages_Total:/{print $2; exit}' /proc/meminfo 2>/dev/null || echo unknown)"
  log "hugepages: $before -> $after_total total ($(awk '/^HugePages_Free:/{print $2; exit}' /proc/meminfo 2>/dev/null || echo ?) free)"
  log "MemAvailable: ${avail_kb}kB -> $(mem_available_kb)kB"
fi

# ---- THP ----
step "transparent hugepages -> madvise"
for f in /sys/kernel/mm/transparent_hugepage/enabled; do
  if [ -w "$f" ]; then
    before="$(cat "$f")"
    echo madvise > "$f" 2>/dev/null || warn "write $f failed"
    log "THP: $before -> $(cat "$f" 2>/dev/null)"
  else
    warn "$f not writable (skip)"
  fi
done

# ---- aggressive ----
if [ "$AGGRESSIVE" -eq 1 ]; then
  step "aggressive hints (NOT executed)"
  cat <<'EOF'
建议人工确认后执行（不同发行版服务名各异，先 systemctl list-units 看一眼）：
  systemctl stop    bluetooth cups avahi-daemon snapd thermald 2>/dev/null
  systemctl disable bluetooth cups avahi-daemon snapd thermald 2>/dev/null
  swapoff -a                      # 随机数满配时 swap 触发=掉算力; 确认无 OOM 风险再做
  echo 0 > /proc/sys/vm/swappiness
勿动：sshd / networking / 你实际上栈的服务（本机跑的是 xmr-engine+xmrig）。
EOF
fi

step "done"
if [ "$failures" -gt 0 ]; then
  log "completed with $failures warning(s)"
  exit 1
fi
log "all steps ok"
