#!/bin/sh
set -e
cd "$(dirname "$0")"
chmod +x ./xmr-engine ./xmrig 2>/dev/null || true
if [ -x ./xmrig ]; then
  export XMRIG="$(pwd)/xmrig"
fi
exec ./xmr-engine -config "${ENGINE_CONFIG:-./config.yaml}" "$@"
