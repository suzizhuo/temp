#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$ROOT/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
mkdir -p "$ROOT/logs"
WORKER="$(hostname -s 2>/dev/null || echo rig)"
exec "$ROOT/bin/t-rex" \
  -a etchash \
  --coin etc \
  -o stratum+tcp://etc.2miners.com:1010 \
  -u 0x39736333b8710cda6b4bd48273282b7da21ffb9c \
  -p x \
  -w "$WORKER" \
  --log-path "$ROOT/logs/t-rex.log"
