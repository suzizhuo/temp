#!/usr/bin/env bash
# 启动 Kaspa 挖矿。用法：
#   ./start.sh          单实例，挖到 config.sh 的 ACTIVE_WALLET
#   ./start.sh --dual   双实例：卡组1 -> 钱包1，卡组2（GPUS_2） -> 钱包2
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

DUAL=0
[ "${1:-}" = "--dual" ] && DUAL=1

mkdir -p "$LOG_DIR"

# ---------------- 启动前预检：把问题当着人的面说清楚，别让 screen 吞掉 ----------------
preflight() {
    local ok=1 f
    # 包布局：脚本被单独拷到别处跑时 PACK_DIR 会指错，矿机/日志全部找不到
    for f in config.sh download_miner.sh run_instance.sh oc_tune.sh; do
        if [ ! -f "$PACK_DIR/$f" ]; then
            echo "[!] 包布局异常：缺 $PACK_DIR/$f"
            echo "    kaspa-miner-pack 必须整体上传/解压成一个目录（含所有 .sh），不要把 .sh 单独拷到别处再跑。"
            ok=0
        fi
    done
    command -v screen >/dev/null 2>&1 || { echo "[!] 未安装 screen：sudo apt install -y screen（或改用 systemd_install.sh）"; ok=0; }
    if ! command -v nvidia-smi >/dev/null 2>&1; then
        echo "[!] 未检测到 nvidia-smi：先装 NVIDIA 驱动（sudo apt install -y nvidia-driver-535 && sudo reboot）"
        ok=0
    fi
    if [ ! -x "$MINER_BIN" ]; then
        echo "[!] 未找到矿机：$MINER_BIN"
        echo "    先运行：cd \"$PACK_DIR\" && ./download_miner.sh"
        ok=0
    fi
    [ "$ok" = "1" ] || exit 1
}
preflight

launch() {  # $1 钱包编号  $2 显卡  $3 API端口  $4 会话名
    local w="$1" g="$2" api="$3" sess="$4"
    SCREEN_LS="$(screen -ls 2>/dev/null || true)"
    if echo "$SCREEN_LS" | grep -q "\.${sess}[[:space:]]"; then
        echo "[=] 会话 ${sess} 已在运行，跳过（先 ./stop.sh 再启动）"
        return 0
    fi
    screen -dmS "$sess" bash "$PACK_DIR/run_instance.sh" "$w" "$g" "$api" "$sess"
    echo "[+] 已启动会话 ${sess}：钱包${w} / 显卡 ${g} / API :${api}"
}

if [ "$DUAL" = "1" ]; then
    [ -n "$GPUS_2" ] || { echo "[!] --dual 需要 config.sh 里的 GPUS_2 非空"; exit 1; }
    launch 1 "$GPUS"   "$API_PORT"   kaspa-miner
    launch 2 "$GPUS_2" "$API_PORT_2" kaspa-miner2
else
    launch "$ACTIVE_WALLET" "$GPUS" "$API_PORT" kaspa-miner
fi

# 启动后等待最多 10s，直到看到 lolMiner 进程；否则启动失败，打日志并退非零
DEADLINE=$(( $(date +%s) + 10 ))
while [ "$(date +%s)" -lt "$DEADLINE" ]; do
    if pgrep -f "lolMiner" >/dev/null 2>&1; then break; fi
    sleep 0.5
done

sleep 3
echo ""
echo "[*] screen 会话："
screen -ls 2>/dev/null | grep -E "kaspa-miner" || true
if ! pgrep -f "lolMiner" >/dev/null 2>&1; then
    echo "[!] 未检测到 lolMiner 进程，启动失败。最近日志（$LOG_DIR）："
    for sess in kaspa-miner kaspa-miner2; do
        L="$LOG_DIR/${sess}_current.log"
        [ -e "$L" ] || continue
        echo "--- $L ---"
        tail -n 15 "$L"
    done
    echo "[*] 也可前台单跑看报错：cd \"$PACK_DIR\" && ./run_instance.sh 1 \"*\" 4066 kaspa-miner"
    exit 1
fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo 127.0.0.1)"
echo ""
echo "[*] 实时输出  ：screen -r kaspa-miner"
echo "[*] 状态面板  ：http://${IP}:${API_PORT}/gui"
echo "[*] 矿池收益  ：https://woolypooly.com 搜你的 kaspa: 钱包地址"
echo "[*] 日志目录  ：$LOG_DIR"
if [ "$DUAL" = "1" ]; then
    echo "[*] 双实例已开启：钱包1=$KASPA_WALLET_1 钱包2=$KASPA_WALLET_2"
fi
exit 0
