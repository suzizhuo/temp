#!/usr/bin/env bash
# ============================================================
#  Kaspa 满血挖矿配置（woolypooly 矿池 / lolMiner 1.98a）
#  本文件被其它脚本 source，请勿在此处 set -e 之类
# ============================================================

# 脚本包自身目录（自动定位，无需修改）
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------- 钱包 ----------------
# 两个地址均通过 rusty-kaspa 官方算法校验（bech32 变体 / version=0 / 32B payload）
# 校验方法：./wallet_tool.sh verify
KASPA_WALLET_1="kaspa:qqrwgt0kpe7c58y90plagddqpsky9046eh88epf0t2zsje3z4vxg7hfrgqh4m"
KASPA_WALLET_2="kaspa:qrhgpcrt303kaz3pvsz3ulm95lrjet6jp956e2qrmhe5tqna3ezh5hrtklcqn"

# 单实例默认打到 ACTIVE_WALLET 指定的地址；切换：./wallet_tool.sh switch 1|2
ACTIVE_WALLET=1

# ---------------- 矿工与矿池 ----------------
WORKER="linux-rig-01"        # 矿池后台区分机器，建议改成你的机器名
MINER_PASS="x"               # woolypooly 密码固定填 x

# 主池（lolMiner 参数：--pool/--user/--worker/--pass 可重复，实现原生故障切换）
POOL_PRIMARY="stratum+tcp://kaspa.woolypooly.com:3333"

# 备池：主池 5 次快速掉线后自动切换。若端口不通，用 ./verify_pool.sh 探测后改这里
POOL_BACKUPS="stratum+tcp://kaspa.woolypooly.com:3334 stratum+tcp://kaspa.woolypooly.com:3335"

# SSL 池（选项；若矿池开启 TLS 端口，把主池改成其地址即可）
POOL_TLS=""

# ---------------- 矿机程序 ----------------
MINER_VERSION="1.98a"
MINER_URL="https://github.com/Lolliedieb/lolMiner-releases/releases/download/1.98a/lolMiner_v1.98a_Lin64.tar.gz"
MINER_SHA256="0b8078299654a12846e4967f1db3506409cfb8b1031687a910965d1a99c6f270"
MINER_BIN="$PACK_DIR/lolMiner_linux/lolMiner"

# ---------------- 日志 / API ----------------
LOG_DIR="$PACK_DIR/logs"
API_PORT="4066"             # lolMiner --apiport，浏览器 http://矿机IP:4066/gui 看统计
API_PORT_2="4067"           # 双实例时第二个实例的 API 端口

# ---------------- 显卡 ----------------
# "*" = 全部显卡；或逗号列表，如 "0,1,2,3"（lolMiner --devices）
GPUS="*"
GPUS_2="4,5,6,7"            # start.sh --dual 时第二实例使用的显卡

# ---------------- 满血超频（oc_tune.sh 执行，可被命令行参数覆盖）----------------
PERSISTENCE=1               # 1 = 开启 nvidia-smi 持久模式（强烈建议）
POWER_LIMIT="*"             # 功耗墙 W，例 300；"*" = 不动
CORE_CLOCK_LOCK="*"         # 核心锁频 MHz，例 1500；"*" = 不动（lolMiner 文档：Ampere/Turing 生效）
MEM_CLOCK_LOCK="810"        # 显存锁频 MHz。lolMiner 官方 KASPA 预设 810MHz：
                            #   kHeavyHash 吃矩阵算力，显存带宽压力小，锁 810 功耗暴降
                            #   想榨干显存带宽把这里改 "*"，或用 MEM_CLOCK_OFFSET 微调
MEM_CLOCK_OFFSET=""         # 显存偏移 MHz（与 MEM_CLOCK_LOCK 二选一）
FAN_SPEED="*"               # 风扇 %；"*" = 不动

# ---------------- 运行稳定性 ----------------
WATCHDOG_MODE="exit"        # off | exit | script（exit：崩溃退出码 42，外层自动重启）
RESTART_DELAY=5             # 矿机退出后重启等待秒数
T_START=""                  # 低于该温度恢复挖矿，例 70；空 = 不启用
T_STOP=""                   # 达到该温度停该卡，例 83；空 = 不启用
STATS_FORMAT="speed,poolHr,shares,sharesPerMin,power,hrPerWatt,coreT,juncT,memT"
SILENCE=1                   # 0 最详细 / 1 无 job / 2 无 share / 3 只出统计

# ---------------- 目录 ----------------
MINER_DIR="$PACK_DIR/lolMiner_linux"
