#!/usr/bin/env bash
# NVIDIA 满血调优：持久模式 + 功耗墙 + 锁频 + 风扇 + KASPA 显存 810 预设
# 用法：
#   sudo ./oc_tune.sh            按 config.sh 应用
#   sudo ./oc_tune.sh apply [功耗W] [核心MHz] [显存MHz] [风扇%]
#   sudo ./oc_tune.sh reset      清除所有锁频
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

MODE="${1:-apply}"
PL="${2:-$POWER_LIMIT}"
CORE="${3:-$CORE_CLOCK_LOCK}"
MEM="${4:-$MEM_CLOCK_LOCK}"
FAN="${5:-$FAN_SPEED}"

command -v nvidia-smi >/dev/null 2>&1 || { echo "[!] 未找到 nvidia-smi"; exit 1; }
is_on() { [ -n "$1" ] && [ "$1" != "*" ]; }

if [ "$MODE" = "reset" ]; then
    echo "[+] 清除锁频..."
    N=$(nvidia-smi -L | wc -l)
    for i in $(seq 0 $((N-1))); do
        sudo nvidia-smi -i "$i" -rgc || true
        sudo nvidia-smi -i "$i" -rmc || true
    done
    echo "[OK] 已恢复默认频率。"
    exit 0
fi

if [ "$PERSISTENCE" = "1" ]; then
    echo "[+] 开启持久模式..."
    sudo nvidia-smi -pm 1 || true
fi

N=$(nvidia-smi -L | wc -l)
echo "[+] 检测到 $N 张显卡，开始调优..."

for i in $(seq 0 $((N-1))); do
    if is_on "$PL";   then echo "  GPU$i 功耗墙 ${PL}W";      sudo nvidia-smi -i "$i" -pl "$PL";   fi
    if is_on "$CORE"; then echo "  GPU$i 核心锁频 ${CORE}MHz"; sudo nvidia-smi -i "$i" -lgc "$CORE"; fi
    if is_on "$MEM";  then
        echo "  GPU$i 显存锁频 ${MEM}MHz"
        echo "      （lolMiner 官方 KASPA 预设：kHeavyHash 显存带宽需求低，锁 810MHz 功耗暴降）"
        sudo nvidia-smi -i "$i" -lmc "$MEM"
    fi
    if is_on "$FAN";  then echo "  GPU$i 风扇 ${FAN}%"; sudo nvidia-smi -i "$i" -fan "$FAN" || true; fi
done

echo ""
echo "[+] 当前显卡状态："
nvidia-smi --query-gpu=index,name,power.draw,clocks.sm,clocks.mem,temperature.gpu --format=csv
echo ""
echo "[OK] 调优完成（重启后失效，重跑本脚本即可）。"
echo "    注：--cclk 锁核在 lolMiner 文档标明 Ampere/Turing 生效；nvidia-smi -lgc/-lmc 各级架构通用。"
