# HeavyHash 满血挖矿脚本包（Linux / woolypooly / lolMiner 1.98a）

按 `../方案.MD` 实现的完整执行包。目标：Linux + NVIDIA 机器满血挖 HeavyHash 家族币种，
算力直打你的钱包；三处配置（算法 / 钱包 / 矿池）联动即可切换币种。

## 0. 重要：算法已从 KASPA 切换到 KARLSENV2

**实测证据**：本包锁定的 lolMiner `1.98a`（sha256 `0b807829…f270`）执行
`--algo KASPA` 直接报错：

```
Error: --algo option "KASPA" is not supported
List of supported algorithms: ... KARLSENV2 / PYRIN / PYRINV2 ...
```

该版本的算法列表里 HeavyHash 家族只剩三项，脚本因此全面参数化：

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `ALGO` | `KARLSENV2` | lolMiner 支持的三选一：`KARLSENV2` / `PYRIN` / `PYRINV2` |
| `POOL_COIN` | `karlsen` | 矿池子域名：`karlsen.woolypooly.com` |
| `ADDR_PREFIX` | `karlsen:` | 地址前缀，`wallet_tool.sh` 与 `run_instance.sh` 校验共用 |

**三个后果**：
1. 原 Kaspa 的两个内置地址已作废（`kaspa:` 前缀不被本矿机接受）。
2. `config.sh` 的 `WALLET_1/WALLET_2` 必须填**你自己的 `karlsen:` 地址**（占位符会在启动时被拒绝并提示）。
3. 矿池域名随 `POOL_COIN` 变，端口用 `./verify_pool.sh` 探测校正。

> 榨干内存/GPU 的调优手段（`-ac` 锁最高核心+显存 clock 对、2.5GiB 大页、功耗墙、THP）与算法无关，
> 换 `PYRIN` / `PYRINV2` 完全复用。

## 1. 文件清单

```
config.sh            币种/算法/钱包/矿池/超频/稳定性配置（核心）
install_deps.sh      装依赖 + 驱动检查
download_miner.sh    下载 lolMiner（sha256 校验）
mem_tune.sh          系统内存满血：2.5GiB 大页 / swappiness / THP / 可选 swapoff
oc_tune.sh           NVIDIA 满血调优（持久模式/-ac 锁频/功耗墙）+ 自动调 mem_tune
start.sh             启动挖矿（screen 后台；--dual 双实例双钱包）
run_instance.sh      单实例参数组装 + 崩溃守护循环（start.sh 内部调用）
stop.sh              停止
status.sh            状态/算力/份额
monitor.sh           实时监控（5s 刷新）
verify_pool.sh       矿池端口探测（TCP + stratum 握手）
wallet_tool.sh       钱包校验 / 切换默认钱包
emergency.sh         watchdog script 模式钩子
systemd_install.sh   开机自启（与 screen 二选一）
README.md            本文件
```

## 2. 满血激活四步

```bash
# 步骤 0：上传本目录到 Linux 机器，进入后给执行权限
cd kaspa-miner-pack && chmod +x *.sh

# 步骤 1：装依赖 + 下矿机（自动校验 sha256）
sudo ./install_deps.sh
./download_miner.sh     # 必须看到 [OK] .../lolMiner_linux/lolMiner 就绪

# 步骤 2：填你自己的钱包（必做，否则 start.sh 会在预检阶段拒绝启动）
vi config.sh           # 改 WALLET_1 / WALLET_2 / WORKER
./wallet_tool.sh verify

# 步骤 3：满血调优 + 启动
sudo ./oc_tune.sh      # 持久模式 + 每卡最高核心/显存 clock 对(-ac) + 系统内存大页
./start.sh             # 默认挖到钱包1
```

验证是否真的在挖：

```bash
./status.sh            # 看 Total Speed / Accepted
./monitor.sh           # 实时
# 或浏览器打开 http://<矿机IP>:4066/gui
```

收益核对：https://woolypooly.com → 搜你的 `karlsen:` 地址。

## 3. 关键设计

- **矿机与版本**：lolMiner `1.98a`（GitHub Releases，sha256 已锁定，不一致拒绝运行）。
- **算法**：`ALGO`（`config.sh`）透传 `--algo`；`KARLSENV2` 1.0% dev fee、`--pers` 不需要。
- **故障切换**：lolMiner 支持多组 `--pool/--user`（主池短时间掉线 5 次切下一组）。
- **满血关键参数**：
  - `oc_tune.sh` 在 `MEM_CLOCK_LOCK="*"` 时把每卡锁到官方支持的最高核心+显存 clock 对
    （`nvidia-smi -ac`，显存带宽与核心均拉满），比 `--mclk 810` 省电预设更激进；
    接线方式：改 `config.sh` 的 `MEM_CLOCK_LOCK="810"` 再跑 `./oc_tune.sh`。
  - `--pl` 功耗墙、`--fan` 风扇；`POWER_LIMIT="*"` = 不设限（温度用 `T_STOP/T_START` 兜底）。
  - `--watchdog exit` + `run_instance.sh` 守护循环：矿机崩溃退出码 42 自动拉起；
    连续 3 次运行 <20 秒的非 42 退出会断然停掉并写日志（避免参数错误死循环刷日志）。
  - `--apiport` 网页统计面板 `/gui`；`--statsformat` 自定义统计项。
- **内存满血**（`mem_tune.sh`，`oc_tune.sh` 自动调用）：`vm.nr_hugepages=1280`（2.5GiB）、
  `swappiness=10`、`vfs_cache_pressure=50`、`THP=madvise`；`SWAPOFF=1` 才执行 `swapoff -a`。
- **日志与可诊断性**：`run_instance.sh` 一开始就建日志并把全部输出重定向进去，
  "log 下无任何内容"不再可能；`start.sh` 启动前预检（包布局 / screen / nvidia-smi /
  矿机二进制 / 钱包非占位符），失败即打印原因并自动 `tail -n 15` 日志。
- **双钱包两种用法**：
  1. 切换默认钱包：`./wallet_tool.sh switch 2` 然后 `./stop.sh && ./start.sh`
  2. 同一台机两张卡组分打两个钱包：改 `config.sh` 的 `GPUS_2`，然后 `./start.sh --dual`
     （实例1 → 钱包1 用 `GPUS`，实例2 → 钱包2 用 `GPUS_2`，API 端口自动错开）

## 4. 端口说明

`karlsen.woolypooly.com:3333` 为按 woolypooly 习惯格式拼出的默认值，
**本机无法直连官网核实时**，所以：

- `POOL_PRIMARY` 默认 3333，`POOL_BACKUPS` 内置 3334/3335；
- 先跑 `./verify_pool.sh` 自动探测（TCP + 发 `mining.subscribe` 看握手），
  把可用端口填回 `config.sh` 即可；探测不通只是当前网络问题，不影响本机矿机运行。
- 换币种（`PYRIN` / `PYRINV2`）时同步改 `POOL_COIN`，并用 `./verify_pool.sh <新域名>` 重探。

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| 启动即退出、日志无内容 | 已不可能：`run_instance.sh` 日志先行，直接 `tail -n 15 logs/kaspa-miner_current.log` |
| `[!] 钱包还是占位符未填` | `config.sh` 填你自己的 `karlsen:` 地址 |
| `[!] 包布局异常` | 目录被拆散了：`kaspa-miner-pack` 必须整体上传，不要只拷 `.sh` |
| `[!] 未找到矿机` | `./download_miner.sh` |
| `Error: --algo ... not supported` | 证明用了旧版脚本/旧版 `config.sh`；本包 `ALGO=KARLSENV2` 已按实测修正 |
| `未检测到 nvidia-smi` | 装驱动：`sudo apt install -y nvidia-driver-535 && sudo reboot` |
| `pool connect failed` | 跑 `./verify_pool.sh` 换端口；防火墙放行外网 TCP 3333 |
| 算力为 0 或极低 | `oc_tune.sh` 没跑：频率没锁；确认 `nvidia-smi` 里 clocks 已变化 |
| 功耗高想降温 | `MEM_CLOCK_LOCK="810"` 省电预设，再降 `POWER_LIMIT` |
| 想开机自启 | `sudo ./systemd_install.sh`（用了它就别再开 screen） |
| 切到钱包2 | `./wallet_tool.sh switch 2 && ./stop.sh && ./start.sh` |

## 6. 卸载

```bash
./stop.sh
sudo ./oc_tune.sh reset      # 清锁频（可选）
sudo ./mem_tune.sh reset     # 恢复 swappiness/THP（可选）
# 若装过 systemd：sudo ./systemd_install.sh 卸载命令见其输出
rm -rf kaspa-miner-pack logs
```

---

钱包地址格式 `karlsen:` + bech32 变体（与 `kaspa:` 同族的非标准 bech32，
version=0 / 32 字节 payload / 8 字符校验）。校验命令：`./wallet_tool.sh verify`。
