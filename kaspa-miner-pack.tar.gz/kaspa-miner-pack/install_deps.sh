#!/usr/bin/env bash
# 安装系统依赖 + 检查 NVIDIA 驱动（lolMiner Linux 版需 470+ 驱动）
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/config.sh"

echo "[1/4] 安装系统依赖..."
if command -v apt >/dev/null 2>&1; then
    sudo apt update -y
    sudo apt install -y curl wget jq screen tmux python3 ca-certificates pciutils
elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y curl wget jq screen tmux python3 ca-certificates pciutils
elif command -v yum >/dev/null 2>&1; then
    sudo yum install -y curl wget jq screen tmux python3 ca-certificates pciutils
else
    echo "[!] 未识别的包管理器，请手动安装：curl wget jq screen python3"
fi

echo "[2/4] 检查 NVIDIA 驱动..."
if ! command -v nvidia-smi >/dev/null 2>&1; then
    echo "[!] 未检测到 nvidia-smi。Ubuntu 示例："
    echo "    sudo apt install -y nvidia-driver-535 && sudo reboot"
    exit 1
fi
DRV="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)"
echo "    驱动版本：$DRV"

echo "[3/4] 显卡列表："
nvidia-smi --query-gpu=index,name,memory.total,power.max_limit --format=csv

echo "[4/4] 验证矿池与钱包（可选，网络不通时跳过）："
./verify_pool.sh || echo "[!] 矿池探测失败，只表示当前网络到 woolypooly 不通，不影响矿机运行"
./wallet_tool.sh verify || echo "[!] 钱包校验未通过，请检查 config.sh 中的地址"

echo "[OK] 依赖安装完成。"
