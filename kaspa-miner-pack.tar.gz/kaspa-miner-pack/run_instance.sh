#!/usr/bin/env bash
# 单个矿机实例：拼 lolMiner 参数 + 守护循环（watchdog exit 42 / 崩溃自动重启）
# 由 start.sh 调用，不单独使用
# $1 = 钱包编号 1|2   $2 = 显卡列表("*" 或 "0,1")   $3 = API 端口   $4 = screen 会话名
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

WIDX="${1:?钱包编号 1|2}"
GPUS_N="${2:-*}"
API_PORT_N="${3:-$API_PORT}"
SESSION="${4:-kaspa-miner}"

case "$WIDX" in
    1) WALLET="$KASPA_WALLET_1" ;;
    2) WALLET="$KASPA_WALLET_2" ;;
    *) echo "[!] 钱包编号必须是 1 或 2"; exit 1 ;;
esac

# 钱包地址基本检查（kaspa: + 61 位 bech32 字符；完整校验见 wallet_tool.sh verify）
if [ "${#WALLET}" -ne 67 ] || [ "${WALLET:0:6}" != "kaspa:" ]; then
    echo "[!] 钱包地址格式不对：$WALLET"
    exit 1
fi

is_on() { [ -n "$1" ] && [ "$1" != "*" ]; }   # "空 或 *" 表示不设置

# ---------------- 组装 lolMiner 参数 ----------------
ARGS=( --algo KASPA --worker "$WORKER" --pass "$MINER_PASS" )

# 矿池（lolMiner 多组 --pool/--user 即原生故障切换）
if is_on "$POOL_TLS"; then
    ARGS+=( --pool "$POOL_TLS" --user "$WALLET" )
fi
for p in $POOL_PRIMARY $POOL_BACKUPS; do
    if is_on "$p"; then
        ARGS+=( --pool "$p" --user "$WALLET" )
    fi
done

# 显卡选择（lolMiner --devices 逗号列表）
if is_on "$GPUS_N"; then
    ARGS+=( --devices "$GPUS_N" )
fi

# 满血超频（这些参数会被 linux 下的 NVML 应用，同样可交给 oc_tune.sh）
if is_on "$CORE_CLOCK_LOCK"; then ARGS+=( --cclk "$CORE_CLOCK_LOCK" ); fi
if is_on "$MEM_CLOCK_LOCK"; then
    ARGS+=( --mclk "$MEM_CLOCK_LOCK" )
elif is_on "$MEM_CLOCK_OFFSET"; then
    ARGS+=( --moff "$MEM_CLOCK_OFFSET" )
fi
if is_on "$POWER_LIMIT"; then ARGS+=( --pl "$POWER_LIMIT" ); fi
if is_on "$FAN_SPEED";   then ARGS+=( --fan "$FAN_SPEED" ); fi

# API / 温度保护 / 看门狗 / 统计
ARGS+=( --apiport "$API_PORT_N" )
if [ "$WATCHDOG_MODE" != "off" ] && [ -n "$WATCHDOG_MODE" ]; then
    ARGS+=( --watchdog "$WATCHDOG_MODE" )
fi
if is_on "$T_STOP";  then ARGS+=( --tstop "$T_STOP" ); fi
if is_on "$T_START"; then ARGS+=( --tstart "$T_START" ); fi
if is_on "$STATS_FORMAT"; then ARGS+=( --statsformat "$STATS_FORMAT" ); fi
if is_on "$SILENCE"; then ARGS+=( --silence "$SILENCE" ); fi

# 干跑模式：只打印最终命令，不启动矿机（DRY_RUN=1 ./run_instance.sh 1 "*" 4066 test）
if [ "${DRY_RUN:-0}" = "1" ]; then
    echo "[DRY-RUN] $MINER_BIN ${ARGS[*]}"
    exit 0
fi

[ -x "$MINER_BIN" ] || { echo "[!] 未找到 ${MINER_BIN}，先运行 ./download_miner.sh"; exit 1; }

# ---------------- 启动守护循环 ----------------
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/${SESSION}_$(date +%Y%m%d_%H%M%S).log"
ln -sf "$LOG" "$LOG_DIR/${SESSION}_current.log"

{
    echo "==== $(date '+%F %T') 启动 ===="
    echo "钱包：   $WALLET"
    echo "矿工：   $WORKER"
    echo "显卡：   $GPUS_N"
    echo "矿池：   ${POOL_PRIMARY} （故障切换：${POOL_BACKUPS}）"
    echo "API：    http://127.0.0.1:${API_PORT_N}/gui"
    echo "命令：   $MINER_BIN ${ARGS[*]}"
    echo "======================="
} >> "$LOG"

while true; do
    set +e
    "$MINER_BIN" "${ARGS[@]}" >> "$LOG" 2>&1
    RC=$?
    set -e
    echo "[$(date '+%F %T')] 矿机退出 rc=${RC}，${RESTART_DELAY}s 后重启" >> "$LOG"
    sleep "$RESTART_DELAY"
done
