#!/usr/bin/env bash
# NVIDIA 满血调优：持久模式 + 功耗墙 + 锁频 + 风扇 + KASPA 显存 810 预设
# 用法：
#   sudo ./oc_tune.sh            按 config.sh 应用
#   sudo ./oc_tune.sh apply [功耗W] [核心MHz] [显存MHz] [风扇%]
#   sudo ./oc_tune.sh reset      清除所有锁频
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

MODE="${1:-apply}"
PL="${2:-$POWER_LIMIT}"
CORE="${3:-$CORE_CLOCK_LOCK}"
MEM="${4:-$MEM_CLOCK_LOCK}"
FAN="${5:-$FAN_SPEED}"

command -v nvidia-smi >/dev/null 2>&1 || { echo "[!] 未找到 nvidia-smi"; exit 1; }
is_on() { [ -n "$1" ] && [ "$1" != "*" ]; }

if [ "$MODE" = "reset" ]; then
    echo "[+] 清除锁频..."
    N=$(nvidia-smi -L | wc -l)
    for i in $(seq 0 $((N-1))); do
        sudo nvidia-smi -i "$i" -rgc || true
        sudo nvidia-smi -i "$i" -rmc || true
    done
    echo "[OK] 已恢复默认频率。"
    exit 0
fi

# ---- 系统内存满血（与 GPU 调优同步） ----
if [ "$MEM_TUNE" = "1" ]; then
    echo "[+] 内存满血调优..."
    sudo bash "$PACK_DIR/mem_tune.sh" apply || echo "[!] mem_tune.sh 执行失败，继续 GPU 调优"
fi

if [ "$PERSISTENCE" = "1" ]; then
    echo "[+] 开启持久模式..."
    sudo nvidia-smi -pm 1 || true
fi

N=$(nvidia-smi -L | wc -l)
echo "[+] 检测到 $N 张显卡，开始调优..."

max_clocks() {  # $1 = index；输出 "SM MEM"
    nvidia-smi -i "$1" --query-gpu=clocks.max.sm,clocks.max.mem --format=csv,noheader,nounits 2>/dev/null | tr -d ' ' | tr ',' ' '
}

for i in $(seq 0 $((N-1))); do
    # set -e 下旧版任意一张卡的 nvidia-smi 失败都会中断整轮调优，后面的卡全部不调；
    # 现在每张卡独立容错：失败的步骤打印原因，继续调下一张、下一项。
    if is_on "$PL";   then echo "  GPU$i 功耗墙 ${PL}W";      sudo nvidia-smi -i "$i" -pl "$PL"   || echo "  [!] GPU$i -pl 失败（该卡型可能不支持此功耗值）"; fi
    if is_on "$CORE"; then echo "  GPU$i 核心锁频 ${CORE}MHz"; sudo nvidia-smi -i "$i" -lgc "$CORE" || echo "  [!] GPU$i -lgc 失败（该卡型可能不支持锁核）"; fi
    if is_on "$MEM";  then
        echo "  GPU$i 显存锁频 ${MEM}MHz"
        sudo nvidia-smi -i "$i" -lmc "$MEM" || echo "  [!] GPU$i -lmc 失败（该卡型可能不支持锁显存）"
    elif [ "$MEM_CLOCK_LOCK" = "*" ]; then
        # 榨干 GPU：把每卡锁到官方支持的最高核心+显存 clock 对（-ac）
        read -r MAX_SM MAX_MEM < <(max_clocks "$i")
        if [ -n "$MAX_SM" ] && [ -n "$MAX_MEM" ]; then
            echo "  GPU$i 锁到最高 clock 对：SM=${MAX_SM}MHz MEM=${MAX_MEM}MHz（-ac，榨显存/核心满血）"
            sudo nvidia-smi -i "$i" -rgc >/dev/null 2>&1 || true
            sudo nvidia-smi -i "$i" -rmc >/dev/null 2>&1 || true
            sudo nvidia-smi -i "$i" -ac "$MAX_SM $MAX_MEM" || echo "  [!] GPU$i -ac 失败，该卡型可能不支持"
        else
            echo "  [!] GPU$i 读不到最大 clock，跳过显存锁频"
        fi
    fi
    if is_on "$FAN";  then echo "  GPU$i 风扇 ${FAN}%"; sudo nvidia-smi -i "$i" -fan "$FAN" || echo "  [!] GPU$i -fan 失败（该卡型可能不支持手动风扇）"; fi
done

echo ""
echo "[+] 当前显卡状态："
nvidia-smi --query-gpu=index,name,power.draw,clocks.sm,clocks.mem,temperature.gpu --format=csv
echo ""
echo "[OK] 调优完成（重启后失效，重跑本脚本即可）。"
echo "    注：--cclk 锁核在 lolMiner 文档标明 Ampere/Turing 生效；nvidia-smi -lgc/-lmc/-ac 各级架构通用；"
echo "    MEM_CLOCK_LOCK=\"*\" 时以 -ac 锁各卡最大支持 clock 对，即显存带宽与核心均拉满。"
