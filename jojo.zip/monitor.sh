#!/usr/bin/env bash
# 实时监控（5 秒刷新）：显卡 + 矿机输出。Ctrl+C 退出
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

trap 'echo; echo "[*] 监控退出"; exit 0' INT
echo "按 Ctrl+C 退出监控..."
sleep 1

# 当前生效钱包（跟 wallet_tool.sh switch 的 ACTIVE_WALLET 走，不再写死钱包1）
_w="WALLET_${ACTIVE_WALLET}"
ACTIVE_ADDR="${!_w:-$WALLET_1}"
ACTIVE_ADDR_SHORT="${ACTIVE_ADDR:0:20}..."

while true; do
    clear
    echo "=============== ${POOL_COIN} 满血监控 $(date '+%F %T') ==============="
    echo "钱包：钱包${ACTIVE_WALLET}(${ACTIVE_ADDR_SHORT})  矿工：${WORKER}  主池：${POOL_PRIMARY}"
    echo "-------------------------------------------------------------"
    if command -v nvidia-smi >/dev/null 2>&1; then
        nvidia-smi --query-gpu=index,name,temperature.gpu,power.draw,utilization.gpu,clocks.mem,clocks.sm,fan.speed --format=csv
    fi
    echo "-------------------------------------------------------------"
    for sess in kaspa-miner kaspa-miner2; do
        LOG="$LOG_DIR/${sess}_current.log"
        [ -e "$LOG" ] || continue
        echo "[${sess}]"
        # 优先显示算力/份额行；没有才退回原始尾部，避免同一行重复打印两次
        HIT="$(grep -E "Total Speed|Accepted|Rejected|Connected|Pool" "$LOG" 2>/dev/null | tail -n 3)"
        if [ -n "$HIT" ]; then
            echo "$HIT"
        else
            tail -n 3 "$LOG"
        fi
    done
    echo "============================================================="
    sleep 5
done
