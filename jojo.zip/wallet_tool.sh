#!/usr/bin/env bash
# 钱包工具：verify 校验地址 / switch 切换默认钱包 / show 展示地址
# Karlsen（以及 Pyrin 等 Kaspa 家族链）地址 = 非标准 bech32 变体
# （60 位寄存器 polymod + 8 字符校验），实现按 rusty-kaspa crypto/addresses/src/bech32.rs 逐行复刻。
# 前缀不再写死 "kaspa"，改用 config.sh 的 ADDR_PREFIX，换币种只需改一处。
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

kaspa_addr_check() {
    # $1 = 地址；输出 "OK <hex>" 或错误原因；需要 python3
    python3 - "$1" "$ADDR_PREFIX" <<'PY'
import sys
addr, PREFIX = sys.argv[1], sys.argv[2]
CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
GENS = [0x98f2bc8e61, 0x79b76d99e2, 0xf33e5fb3c4, 0xae2eabe2a8, 0x1e4f43e470]
def polymod(vals):
    c = 1
    for d in vals:
        c0 = c >> 35
        c = ((c & 0x07ffffffff) << 5) ^ d
        for i, g in enumerate(GENS):
            if (c0 >> i) & 1:
                c ^= g
    return c ^ 1
def conv8to5(b):
    out = [0] * (len(b) * 8 // 5 + (0 if len(b) % 5 == 0 else 1))
    idx = buff = bits = 0
    for x in b:
        buff = (buff << 8) | x; bits += 8
        while bits >= 5:
            bits -= 5; out[idx] = buff >> bits; buff &= (1 << bits) - 1; idx += 1
    if bits > 0:
        out[idx] = buff << (5 - bits)
    return out
def conv5to8(v):
    out = [0] * (len(v) * 5 // 8)
    idx = buff = bits = 0
    for x in v:
        buff = (buff << 5) | x; bits += 5
        while bits >= 8:
            bits -= 8; out[idx] = buff >> bits; buff &= (1 << bits) - 1; idx += 1
    return out
pfx = [ord(c) & 31 for c in PREFIX[:-1]]   # 前缀不含尾部分隔符
def checksum(p): return polymod(pfx + [0] + p + [0]*8)
if not addr.startswith(PREFIX):
    print(f"FAIL 前缀必须是 {PREFIX}"); sys.exit(1)
data = addr[len(PREFIX):]
if len(data) < 53:
    print(f"FAIL 长度 {len(data)} 过短（不含前缀，应 ≥53）"); sys.exit(1)
bad = sorted({c for c in data if c not in CHARSET})
if bad:
    print(f"FAIL 含非法字符 {bad}（bech32 不含 1/b/i/o）"); sys.exit(1)
u5 = [CHARSET.index(c) for c in data]
if checksum(u5[:-8]) != int.from_bytes(conv5to8(u5[-8:]), "big"):
    print("FAIL 校验和错误（地址可能抄错）"); sys.exit(1)
p8 = conv5to8(u5[:-8])
if len(p8) != 33 or p8[0] != 0:
    print(f"FAIL payload 异常 len={len(p8)} version={p8[0]}"); sys.exit(1)
print("OK " + bytes(p8[1:]).hex())
PY
}

cmd="${1:-show}"

case "$cmd" in
    verify)
        echo "[*] 校验 config.sh 中的两个钱包地址（算法：${ALGO} / 前缀：${ADDR_PREFIX}）："
        for n in 1 2; do
            var="WALLET_${n}"
            addr="${!var}"
            res="$(kaspa_addr_check "$addr")" || { echo "  钱包${n} ${addr} -> $res"; exit 1; }
            echo "  钱包${n} ${addr}"
            echo "        ${res%% *}  32字节payload=${res##* }"
        done
        echo "[OK] 两个地址均为合法 ${POOL_COIN} 主网地址（version=0）"
        ;;
    switch)
        sel="${2:-}"
        if [ "$sel" != "1" ] && [ "$sel" != "2" ]; then
            echo "用法：$0 switch 1|2"; exit 1
        fi
        sed -i.bak "s/^ACTIVE_WALLET=.*/ACTIVE_WALLET=${sel}/" "$PACK_DIR/config.sh"
        echo "[OK] 默认钱包已切换为 ${sel}，重启挖矿后生效（./stop.sh && ./start.sh）"
        ;;
    show|*)
        echo "币种：${POOL_COIN}（算法 ${ALGO}）默认挖矿钱包：钱包${ACTIVE_WALLET}"
        echo "  钱包1 = $WALLET_1"
        echo "  钱包2 = $WALLET_2"
        ;;
esac
