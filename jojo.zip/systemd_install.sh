#!/usr/bin/env bash
# 安装 systemd 开机自启服务（与 screen 二选一，不要同时用）
# 用法：
#   sudo ./systemd_install.sh            单实例（钱包 = config.sh 的 ACTIVE_WALLET）
#   sudo ./systemd_install.sh --dual     双实例（kaspa-miner + kaspa-miner2 两个 service）
#   sudo ./systemd_install.sh uninstall  停止并卸载全部 service
#
# 设计说明（旧版两处硬伤，已重构）：
#   1) 旧版 ExecStart=start.sh：start.sh 拉起 screen 后立即 exit 0，
#      Type=simple 的主进程随即退出，Restart=always 会让服务每 10s 空转重启一次。
#      现在每个 service 直接 exec run_instance.sh（自带守护循环，不会主动退出）。
#   2) 旧版 Environment=HOME=$HOME：sudo 运行时 $HOME 是 /root，
#      服务里 HOME 指错，日志/相对路径全跑偏。现在按 SUDO_USER 的 passwd 条目取真实家目录。
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

MODE="${1:-single}"
UNIT_DIR="/etc/systemd/system"

# 运行服务的真实用户与其家目录（sudo 场景 $HOME 不可信，按 passwd 查）
CUR_USER="${SUDO_USER:-$USER}"
if command -v getent >/dev/null 2>&1; then
    CUR_HOME="$(getent passwd "$CUR_USER" | cut -d: -f6)"
else
    CUR_HOME="$(eval echo "~$CUR_USER")"
fi
[ -n "$CUR_HOME" ] && [ -d "$CUR_HOME" ] || CUR_HOME="$PACK_DIR"

write_unit() {  # $1 = service 名  $2 = 钱包编号  $3 = 显卡  $4 = API 端口
    local svc="$1" widx="$2" gpus="$3" api="$4"
    cat > "${UNIT_DIR}/${svc}.service" <<EOF
[Unit]
Description=${POOL_COIN} miner (lolMiner ${MINER_VERSION} / woolypooly) ${svc}
After=network-online.target nvidia-persistenced.service
Wants=network-online.target

[Service]
Type=simple
User=${CUR_USER}
WorkingDirectory=${PACK_DIR}
Environment=HOME=${CUR_HOME}
Environment=GPU_FORCE_64BIT_PTR=0
Environment=GPU_MAX_HEAP_SIZE=100
Environment=GPU_USE_SYNC_OBJECTS=1
Environment=GPU_MAX_ALLOC_PERCENT=100
Environment=GPU_SINGLE_ALLOC_PERCENT=100
ExecStart=/bin/bash -c 'exec "${PACK_DIR}/run_instance.sh" "${widx}" "${gpus}" "${api}" "${svc}"'
# 不需要 ExecStop：systemd 默认 KillMode=control-group，
# stop 时 lolMiner 子进程随 cgroup 一起收掉；双实例模式下也不会误杀另一个实例。
Restart=always
RestartSec=10
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
EOF
    chmod 644 "${UNIT_DIR}/${svc}.service"
}

if [ "$MODE" = "uninstall" ]; then
    echo "[+] 停止并卸载服务..."
    sudo systemctl disable --now kaspa-miner kaspa-miner2 >/dev/null 2>&1 || true
    sudo rm -f "${UNIT_DIR}/kaspa-miner.service" "${UNIT_DIR}/kaspa-miner2.service"
    sudo systemctl daemon-reload
    echo "[OK] 已卸载（日志目录 ${LOG_DIR} 保留，需要手动清理）"
    exit 0
fi

# ---------------- 安装前预检：和 start.sh 同一套底线，别让服务进了重启死循环还不知原因 ----------------
_ok=1
for w in "$WALLET_1" "$WALLET_2"; do
    case "$w" in
        *PLACEHOLDER*)
            echo "[!] 钱包还是占位符未填：$w"
            echo "    改 config.sh 的 WALLET_1/WALLET_2，填 ${ADDR_PREFIX} 开头的真实地址"
            _ok=0 ;;
        *)
            [ "${w:0:${#ADDR_PREFIX}}" = "$ADDR_PREFIX" ] || {
                echo "[!] 钱包前缀应为 ${ADDR_PREFIX}：$w"; _ok=0; } ;;
    esac
done
[ -x "$MINER_BIN" ] || { echo "[!] 未找到矿机：$MINER_BIN（先 ./download_miner.sh）"; _ok=0; }
[ "$_ok" = "1" ] || exit 1

echo "[+] 运行用户：${CUR_USER}（HOME=${CUR_HOME}）"

if [ "$MODE" = "--dual" ]; then
    [ -n "$GPUS_2" ] || { echo "[!] --dual 需要 config.sh 里的 GPUS_2 非空"; exit 1; }
    write_unit kaspa-miner  1 "$GPUS"   "$API_PORT"
    write_unit kaspa-miner2 2 "$GPUS_2" "$API_PORT_2"
    sudo systemctl daemon-reload
    sudo systemctl enable --now kaspa-miner kaspa-miner2
    echo "[OK] 双实例服务已安装并启动：kaspa-miner(钱包1/显卡 ${GPUS}) kaspa-miner2(钱包2/显卡 ${GPUS_2})"
else
    write_unit kaspa-miner "$ACTIVE_WALLET" "$GPUS" "$API_PORT"
    sudo systemctl daemon-reload
    sudo systemctl enable --now kaspa-miner
    echo "[OK] 单实例服务已安装并启动：kaspa-miner(钱包${ACTIVE_WALLET}/显卡 ${GPUS})"
fi

echo ""
echo "    状态：sudo systemctl status kaspa-miner"
echo "    日志：journalctl -u kaspa-miner -f   或   tail -f ${LOG_DIR}/kaspa-miner_current.log"
echo "    停止：sudo systemctl stop kaspa-miner"
echo "    卸载：sudo ./systemd_install.sh uninstall"
echo ""
echo "    注意：systemd 模式下不要再开 screen；screen 模式不要再启动本服务。"
