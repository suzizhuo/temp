#!/usr/bin/env bash
# 启动 HeavyHash 挖矿（lolMiner，算法见 config.sh 的 ALGO）。用法：
#   ./start.sh          单实例，挖到 config.sh 的 ACTIVE_WALLET
#   ./start.sh --dual   双实例：卡组1 -> 钱包1，卡组2（GPUS_2） -> 钱包2
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

DUAL=0
while [ $# -gt 0 ]; do
    case "$1" in
        --dual) DUAL=1 ;;
        -h|--help)
            echo "用法：$0 [--dual]"
            echo "  (无参数)  单实例，挖到 config.sh 的 ACTIVE_WALLET"
            echo "  --dual    双实例：卡组1 -> 钱包1，卡组2（GPUS_2） -> 钱包2"
            exit 0 ;;
        *) echo "[!] 未知参数：$1（只支持 --dual）"; exit 1 ;;
    esac
    shift
done

# 显卡全集（用于 --dual 时给实例1 取补集；nvidia-smi 不可用时留空）
ALL_GPU_IDX=""
if command -v nvidia-smi >/dev/null 2>&1; then
    ALL_GPU_IDX="$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | tr -d ' ' | paste -sd, -)"
fi

# 从 all 中去掉 sub，返回补集（纯 bash，兼容 bash 3.2）
gpu_complement() {  # $1 = 全集 "0,1,2,3"   $2 = 子集 "2,3"
    local all="$1" sub="$2" out="" g s skip
    local -a A B
    IFS=',' read -ra A <<< "$all"
    IFS=',' read -ra B <<< "$sub"
    for g in ${A[@]+"${A[@]}"}; do
        skip=0
        for s in ${B[@]+"${B[@]}"}; do [ "$g" = "$s" ] && skip=1; done
        [ "$skip" = "0" ] && out="${out:+$out,}$g"
    done
    echo "$out"
}

mkdir -p "$LOG_DIR"

# ---------------- 启动前预检：把问题当着人的面说清楚，别让 screen 吞掉 ----------------
preflight() {
    local ok=1 f
    # 包布局：脚本被单独拷到别处跑时 PACK_DIR 会指错，矿机/日志全部找不到
    for f in config.sh download_miner.sh run_instance.sh oc_tune.sh; do
        if [ ! -f "$PACK_DIR/$f" ]; then
            echo "[!] 包布局异常：缺 $PACK_DIR/$f"
            echo "    kaspa-miner-pack 必须整体上传/解压成一个目录（含所有 .sh），不要把 .sh 单独拷到别处再跑。"
            ok=0
        fi
    done
    command -v screen >/dev/null 2>&1 || { echo "[!] 未安装 screen：sudo apt install -y screen（或改用 systemd_install.sh）"; ok=0; }
    if ! command -v nvidia-smi >/dev/null 2>&1; then
        echo "[!] 未检测到 nvidia-smi：先装 NVIDIA 驱动（sudo apt install -y nvidia-driver-535 && sudo reboot）"
        ok=0
    fi
    if [ ! -x "$MINER_BIN" ]; then
        echo "[!] 未找到矿机：$MINER_BIN"
        echo "    先运行：cd \"$PACK_DIR\" && ./download_miner.sh"
        ok=0
    fi
    # 钱包：占位符 / 前缀不对时提前拦下，别等启动后秒退
    local w
    for w in "$WALLET_1" "$WALLET_2"; do
        case "$w" in
            *PLACEHOLDER*)
                echo "[!] 钱包还是占位符未填：$w"
                echo "    改 config.sh 的 WALLET_1/WALLET_2，填 ${ADDR_PREFIX} 开头的真实地址"
                ok=0 ;;
            *)
                [ "${w:0:${#ADDR_PREFIX}}" = "$ADDR_PREFIX" ] || {
                    echo "[!] 钱包前缀应为 ${ADDR_PREFIX}：$w"
                    ok=0
                } ;;
        esac
    done
    [ "$ok" = "1" ] || exit 1
}
preflight

launch() {  # $1 钱包编号  $2 显卡  $3 API端口  $4 会话名
    local w="$1" g="$2" api="$3" sess="$4"
    SCREEN_LS="$(screen -ls 2>/dev/null || true)"
    if echo "$SCREEN_LS" | grep -q "\.${sess}[[:space:]]"; then
        echo "[=] 会话 ${sess} 已在运行，跳过（先 ./stop.sh 再启动）"
        return 0
    fi
    screen -dmS "$sess" bash "$PACK_DIR/run_instance.sh" "$w" "$g" "$api" "$sess"
    echo "[+] 已启动会话 ${sess}：钱包${w} / 显卡 ${g} / API :${api}"
}

if [ "$DUAL" = "1" ]; then
    [ -n "$GPUS_2" ] || { echo "[!] --dual 需要 config.sh 里的 GPUS_2 非空"; exit 1; }
    G1="$GPUS"
    if [ -z "$G1" ] || [ "$G1" = "*" ]; then
        # GPUS="*" 时实例1 原本会连 GPUS_2 的卡一起抢，两个实例在同一批卡上互殴；
        # 自动取补集：实例1 用 GPUS_2 之外的全部卡
        if [ -n "$ALL_GPU_IDX" ]; then
            G1="$(gpu_complement "$ALL_GPU_IDX" "$GPUS_2")"
            if [ -z "$G1" ]; then
                echo "[!] GPUS_2=${GPUS_2} 已覆盖全部显卡，没有卡分给实例1"
                exit 1
            fi
            echo "[*] --dual 且 GPUS=\"*\"，实例1 自动使用 GPUS_2 之外的卡：${G1}"
        else
            echo "[!] --dual 且 GPUS=\"*\"，但读不到显卡列表（nvidia-smi 不可用）"
            echo "    请把 config.sh 的 GPUS 显式设为实例1 的卡（如 \"0,1,2,3\"，不能含 GPUS_2 的卡）"
            exit 1
        fi
    else
        # 显式指定时查重：两组卡重叠会让两个 lolMiner 实例抢同一批卡
        for g in ${G1//,/ }; do
            case ",${GPUS_2}," in *",${g},"*)
                echo "[!] 显卡 ${g} 同时出现在 GPUS(${GPUS}) 和 GPUS_2(${GPUS_2})，双实例会抢卡"
                echo "    改 config.sh：让 GPUS 与 GPUS_2 不重叠；或把 GPUS 设为 \"*\" 自动取补集"
                exit 1 ;;
        esac
    done
    fi
    launch 1 "$G1"     "$API_PORT"   kaspa-miner
    launch 2 "$GPUS_2" "$API_PORT_2" kaspa-miner2
else
    launch "$ACTIVE_WALLET" "$GPUS" "$API_PORT" kaspa-miner
fi

# 启动后等待最多 10s，直到看到 lolMiner 进程；否则启动失败，打日志并退非零
DEADLINE=$(( $(date +%s) + 10 ))
while [ "$(date +%s)" -lt "$DEADLINE" ]; do
    if pgrep -f "lolMiner" >/dev/null 2>&1; then break; fi
    sleep 0.5
done

sleep 3
echo ""
echo "[*] screen 会话："
screen -ls 2>/dev/null | grep -E "kaspa-miner" || true
if ! pgrep -f "lolMiner" >/dev/null 2>&1; then
    echo "[!] 未检测到 lolMiner 进程，启动失败。最近日志（$LOG_DIR）："
    for sess in kaspa-miner kaspa-miner2; do
        L="$LOG_DIR/${sess}_current.log"
        [ -e "$L" ] || continue
        echo "--- $L ---"
        tail -n 15 "$L"
    done
    echo "[*] 也可前台单跑看报错：cd \"$PACK_DIR\" && ./run_instance.sh 1 \"*\" 4066 kaspa-miner"
    exit 1
fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}' || ip -4 route get 1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}' | head -1 || echo 127.0.0.1)"
echo ""
echo "[*] 实时输出  ：screen -r kaspa-miner"
echo "[*] 状态面板  ：http://${IP}:${API_PORT}/gui"
echo "[*] 矿池收益  ：https://woolypooly.com 搜你的 ${POOL_COIN} 钱包地址（${ADDR_PREFIX}）"
echo "[*] 日志目录  ：$LOG_DIR"
if [ "$DUAL" = "1" ]; then
    echo "[*] 双实例已开启：钱包1=$WALLET_1 钱包2=$WALLET_2"
fi
exit 0
