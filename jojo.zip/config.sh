#!/usr/bin/env bash
# ============================================================
#  HeavyHash 家族满血挖矿配置（kryptex KLS / lolMiner 1.98a）
#  本文件被其它脚本 source，请勿在此处 set -e 之类
# ============================================================

# 脚本包自身目录（自动定位，无需修改）
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------- 币种与算法 ----------------
# 实测：lolMiner 1.98a（sha256 0b807829…f270）的 --algo 列表已移除 KASPA，
# 仅存 HeavyHash 家族三项（--pers 均不需要）：
#   KARLSENV2  Karlsenhash V2     dev fee 1.0%   ← 默认，kHeavyHash 直系继承
#   PYRIN      HeavyHash-Pyrin    dev fee 1.0%
#   PYRINV2    HeavyHash-Pyrin V2 dev fee 1.0%
# 切换币种需三处联动：ALGO + 钱包 + 矿池域名（POOL_COIN）。
ALGO="KARLSENV2"
POOL_COIN="karlsen"            # 币种标识：地址前缀校验、监控标题、提示文案共用
ADDR_PREFIX="karlsen:"         # 地址前缀；wallet_tool.sh 校验与 run_instance.sh 预检共用

# ---------------- 钱包 ----------------
# 原 Kaspa（kaspa: 前缀）路线已被 lolMiner 1.98a 移除，两个内置地址随之作废。
# 下面填【你自己】的 karlsen: 地址（Karlsen 官方钱包生成），占位符无法通过校验。
# 已用 wallet_tool.sh verify（bech32 变体校验和）对两个地址实测通过。
WALLET_1="karlsen:qz7ycp254a2k4mlpztuuyg3lpy2x76u4kuq8eg3qx3w4uhf8zqkr5qecsvcpl"
WALLET_2="karlsen:qr87j2uf7cdyr2u449z0gacs4w32jv624vptx5yk5xh354dt35mhuyyzf3z9n"

# 单实例默认打到 ACTIVE_WALLET 指定的地址；切换：./wallet_tool.sh switch 1|2
ACTIVE_WALLET=1

# ---------------- 矿工与矿池 ----------------
WORKER="linux-rig-01"        # 矿池后台区分机器，建议改成你的机器名
# 钱包/矿工拼接分隔符：矿池文档的格式决定
#   "/" = WALLET/WORKER   （kryptex 等斜杠式：拼进 --user，不再传 --worker）
#   "." = WALLET.WORKER   （woolypooly 等点号式：由 lolMiner --worker 追加）
WORKER_SEP="/"

MINER_PASS="x"               # kryptex 密码固定填 x

POOL_HOST="kls.kryptex.network"
# 矿池网页（查收益用）；换池时改这里，start.sh / status.sh 的提示自动跟着变
POOL_WEB="https://pool.kryptex.com/kls"
# verify_pool.sh 探测的候选域名列表（空格或逗号分隔）。发现"TCP 通但 stratum 无回应"
# 就说明这个域名的池子没在跑 KARLSENV2，去币种社区文档找真在跑的矿池，加进来再探。
POOL_TRY_HOSTS="${POOL_HOST}"
POOL_TRY_PORTS="7022"
# 主池（lolMiner 参数：--pool/--user 可重复，实现原生故障切换）
POOL_PRIMARY="stratum+tcp://${POOL_HOST}:7022"

# 备池：主池短时间掉线后 lolMiner 自动切下一组。探测到同池其他可用端口后加在这里，
# 格式同 POOL_PRIMARY，空格分隔；留空 = 只用一个池
POOL_BACKUPS=""

# SSL 池（选项；若矿池开启 TLS 端口，把主池改成其地址即可）
POOL_TLS=""

# ---------------- 矿机程序 ----------------
MINER_VERSION="1.98a"
MINER_URL="https://github.com/Lolliedieb/lolMiner-releases/releases/download/1.98a/lolMiner_v1.98a_Lin64.tar.gz"
MINER_SHA256="0b8078299654a12846e4967f1db3506409cfb8b1031687a910965d1a99c6f270"
MINER_BIN="$PACK_DIR/lolMiner_linux/lolMiner"

# ---------------- 日志 / API ----------------
LOG_DIR="$PACK_DIR/logs"
API_PORT="4066"             # lolMiner --apiport，浏览器 http://矿机IP:4066/gui 看统计
API_PORT_2="4067"           # 双实例时第二个实例的 API 端口

# ---------------- 显卡 ----------------
# "*" = 全部显卡；或逗号列表，如 "0,1,2,3"（lolMiner --devices）
GPUS="*"
GPUS_2="4,5,6,7"            # start.sh --dual 时第二实例使用的显卡

# ---------------- 满血超频（oc_tune.sh 执行，可被命令行参数覆盖）----------------
PERSISTENCE=1               # 1 = 开启 nvidia-smi 持久模式（强烈建议）
POWER_LIMIT="*"             # 功耗墙 W，例 300；"*" = 不动
CORE_CLOCK_LOCK="*"         # 核心锁频 MHz，例 1500；"*" = 不动（lolMiner 文档：Ampere/Turing 生效）
MEM_CLOCK_LOCK="*"          # 显存锁频 MHz。"*" = 不锁，由 lolMiner/oc_tune.sh 决定；
                            #   oc_tune.sh 会把每卡锁到该卡支持的最高核心+显存 clock 对（-ac），真榨 GPU
                            #   保守省电预设填 "810"（HeavyHash 显存带宽压力小，锁低频功耗暴降）
MEM_CLOCK_OFFSET=""         # 显存偏移 MHz（与 MEM_CLOCK_LOCK 二选一）
FAN_SPEED="*"               # 风扇 %；"*" = 不动

# ---------------- 运行稳定性 ----------------
WATCHDOG_MODE="exit"        # off | exit | script（exit：崩溃退出码 42，外层自动重启）
RESTART_DELAY=5             # 矿机退出后重启等待秒数
T_START=""                  # 低于该温度恢复挖矿，例 70；空 = 不启用
T_STOP=""                   # 达到该温度停该卡，例 83；空 = 不启用
# STATS_FORMAT 留空 = 不传 --statsformat。此参数在部分版本取值不当会直接 SIGABRT
# （basic_string::_M_construct null not valid），run_instance.sh 也会按矿机 --help 自动剔除
# 不支持的参数；确认自己的版本支持后可按 lolMiner 文档填回。
STATS_FORMAT=""
SILENCE=1                   # 0 最详细 / 1 无 job / 2 无 share / 3 只出统计

# MINIMAL_MODE=1 时 start.sh/run_instance.sh 只用 --algo/--pool/--user/--apiport 启动，
# 是参数崩溃时的逃生阀（MINIMAL_MODE=1 ./start.sh）。正常挖矿保持 0。
MINIMAL_MODE=0

# ---------------- 内存满血（mem_tune.sh，oc_tune.sh 执行）---------------
MEM_TUNE=1                  # 1 = oc_tune.sh 时顺便调优系统内存（需 root）
HUGEPAGES=1280              # 1280 × 2MiB = 2.5GiB 大页
SWAPPINESS=10               # 降低交换倾向，尽量留在物理内存
SWAPOFF=0                   # 1 = swapoff -a（慎用：仅确认无 OOM 风险后再开）
THP_MODE="madvise"          # madvise | always（transparent hugepages）

# ---------------- 目录 ----------------
MINER_DIR="$PACK_DIR/lolMiner_linux"
