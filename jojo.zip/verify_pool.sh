#!/usr/bin/env bash
# 矿池探测：DNS 预检 + TCP/stratum 握手（全端口并行，秒回）+ 结果分级诊断
# 用法：
#   ./verify_pool.sh                 探测 config.sh 的 POOL_TRY_HOSTS（逗号/空格分隔多个域名）
#   ./verify_pool.sh host1 host2 ... 探测指定域名
#   ./verify_pool.sh --write         探测通过后把最佳池写回 config.sh 的 POOL_PRIMARY
#
# 结果分三级（用户常见困惑：TCP 通但矿机连不上，就是这个 HALF 级）：
#   GOOD   stratum 有握手回应 —— 可用
#   HALF   TCP 能连上但 stratum 无回应 —— 端口活着但后端不服务：
#         典型原因：矿池没上这个币 / 域名指向了通用前端 / 链路被中间设备拦截
#   BAD    TCP 都连不上
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

WRITE_BACK=0
if [ "${1:-}" = "--write" ]; then WRITE_BACK=1; shift; fi

if [ $# -gt 0 ]; then
    HOSTS="$*"
else
    HOSTS="${POOL_TRY_HOSTS:-$POOL_HOST}"
fi
HOSTS="${HOSTS//,/ }"
# 端口候选：优先 config 的 POOL_TRY_PORTS；没配就取 POOL_PRIMARY 里的端口；再不行 3333
PORTS="${POOL_TRY_PORTS:-}"
[ -n "$PORTS" ] || PORTS="$(printf '%s\n' "$POOL_PRIMARY" | sed -n 's/.*://p')"
[ -n "$PORTS" ] || PORTS="3333"

OUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/poolprobe.XXXXXX")"
trap 'rm -rf "$OUT_DIR"' EXIT
i=0

probe() {  # $1=host $2=port $3=序号；结果写 $OUT_DIR/$3
    local host="$1" port="$2" n="$3"
    python3 - "$host" "$port" "$OUT_DIR/$n" <<'PY'
import socket, sys, json, time
host, port, outfile = sys.argv[1], int(sys.argv[2]), sys.argv[3]
t0 = time.time()
def w(s): open(outfile, "w").write(s)
try:
    ip = socket.gethostbyname(host)
except Exception as e:
    w(f"BAD|DNS 解析失败：{e}"); sys.exit(0)
try:
    s = socket.create_connection((ip, port), timeout=4)
except Exception as e:
    rtt = int((time.time()-t0)*1000)
    w(f"BAD|TCP 不通（{rtt}ms）：{type(e).__name__}"); sys.exit(0)
try:
    s.settimeout(4)
    s.sendall((json.dumps({"id":1,"method":"mining.subscribe","params":["poolprobe/1.0"]}) + "\n").encode())
    data = s.recv(2048)
except Exception:
    w(f"HALF|TCP 通（{ip} {int((time.time()-t0)*1000)}ms）但 stratum 无回应：池子没回话（没上这个币/被拦截/后端挂了）"); sys.exit(0)
finally:
    s.close()
text = data.decode(errors="replace").strip()
first = text.splitlines()[0] if text else "(空)"
w(f"GOOD|{int((time.time()-t0)*1000)}ms  stratum 回应：{first[:100]}")
PY
}

echo "[*] 并行探测：$(echo $HOSTS)  端口：${PORTS}"
echo "    每个端口独立 4s TCP + 4s stratum 超时，全部并发"
for h in $HOSTS; do
    for p in $PORTS; do
        i=$((i+1))
        probe "$h" "$p" "$i" &
    done
done
wait

GOOD=(); HALF=0; BAD=0
# 记录顺序即上面提交顺序，线性回放
n=0
for h in $HOSTS; do
    for p in $PORTS; do
        n=$((n+1))
        line="$(cat "$OUT_DIR/$n" 2>/dev/null || echo 'BAD|探测未执行')"
        lvl="${line%%|*}"; msg="${line#*|}"
        case "$lvl" in
            GOOD) echo "  [GOOD] ${h}:${p}  ${msg}"; GOOD+=("${h}:${p}") ;;
            HALF) echo "  [HALF] ${h}:${p}  ${msg}"; HALF=$((HALF+1)) ;;
            *)    echo "  [BAD ] ${h}:${p}  ${msg}"; BAD=$((BAD+1)) ;;
        esac
    done
    echo ""
done

echo "==================== 结论 ===================="
if [ "${#GOOD[@]}" -gt 0 ]; then
    echo "[OK] 可用端口：${GOOD[*]}"
    BEST="${GOOD[0]}"
    echo "    当前 POOL_PRIMARY=$POOL_PRIMARY"
    if [ "$POOL_PRIMARY" != "stratum+tcp://${BEST}" ]; then
        echo "    建议最佳：stratum+tcp://${BEST}"
        if [ "$WRITE_BACK" = "1" ]; then
            sed -i.bak "s|^POOL_PRIMARY=.*|POOL_PRIMARY=\"stratum+tcp://${BEST}\"|" "$PACK_DIR/config.sh"
            echo "[OK] 已写回 config.sh（备份 config.sh.bak）"
        else
            echo "    执行 ./verify_pool.sh --write 可自动写回 config.sh"
        fi
    fi
    exit 0
fi
if [ "$HALF" -gt 0 ]; then
    echo "[!] TCP 能连但 stratum 全部无回应。这说明："
    echo "    1) 该域名/端口后面没有在跑这个币的矿池服务（最常见：矿池没上 KARLSENV2，"
    echo "       或域名解析到了通用前端/网页服务器，白开着 TCP 不干活）；"
    echo "    2) 或本机到该池的链路被中间设备拦截（表现为 TCP 握手好几秒才完成）；"
    echo "    3) 或矿池临时维护。"
    echo "    处理：去币种官网/社区文档找真正在跑 ${ALGO} 的矿池域名，"
    echo "          填进 config.sh 的 POOL_TRY_HOSTS，再跑 ./verify_pool.sh --write。"
    exit 1
fi
echo "[!] TCP 全部不通：检查 DNS、防火墙、外网出口；"
echo "    或换网络（部分地区到海外池子会被干扰）后重试。"
exit 1
