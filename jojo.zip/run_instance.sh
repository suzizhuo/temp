#!/usr/bin/env bash
# 单个矿机实例：拼 lolMiner 参数 + 守护循环（watchdog exit 42 / 崩溃自动重启）
# 由 start.sh 调用，不单独使用
# $1 = 钱包编号 1|2   $2 = 显卡列表("*" 或 "0,1")   $3 = API 端口   $4 = screen 会话名
#
# 约定：日志先行 + 全量重定向进日志。
#   早期失败（缺矿机、包被平铺、参数错）以前会死在 screen 里且不落盘，
#   导致 "log 下无任何内容"、看不到任何原因。现在所有输出都进 logs/<会话>_current.log。
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$PACK_DIR/config.sh"

WIDX="${1:?钱包编号 1|2}"
GPUS_N="${2:-*}"
API_PORT_N="${3:-$API_PORT}"
SESSION="${4:-kaspa-miner}"

is_on() { [ -n "$1" ] && [ "$1" != "*" ]; }   # "空 或 *" 表示不设置

# ---------------- 日志先行：任何早期失败都必须可诊断 ----------------
if ! mkdir -p "$LOG_DIR" 2>/dev/null; then
    LOG_DIR="/tmp"   # 包目录不可写时兜底，绝不静默丢失日志
fi
LOG="$LOG_DIR/${SESSION}_$(date +%Y%m%d_%H%M%S).log"
ln -sf "$LOG" "$LOG_DIR/${SESSION}_current.log" 2>/dev/null || true
echo "[$(date '+%F %T')] run_instance 启动 widx=$WIDX gpus=$GPUS_N api=$API_PORT_N sess=$SESSION" >> "$LOG"

# 从这里开始 stdout/stderr 全进日志；同时保留原始终端 fd 供 DRY_RUN 输出
exec 3>&1 4>&2
exec >> "$LOG" 2>&1

# ---------------- 包布局自检：只拷 .sh 到别处时 PACK_DIR 会指错，提前喊出来 ----------------
for need in config.sh download_miner.sh start.sh run_instance.sh; do
    if [ ! -f "$PACK_DIR/$need" ]; then
        echo "[!] 包布局异常：未找到 $PACK_DIR/$need"
        echo "    kaspa-miner-pack 必须整体上传/解压成一个目录，不要把 .sh 单独拷到别处再跑。"
        echo "    当前 PACK_DIR=$PACK_DIR，请确认所有脚本都在同一目录。"
        exit 1
    fi
done

case "$WIDX" in
    1) WALLET="$WALLET_1" ;;
    2) WALLET="$WALLET_2" ;;
    *) echo "[!] 钱包编号必须是 1 或 2"; exit 1 ;;
esac

# 钱包地址基本检查：前缀须为 config.sh 的 ADDR_PREFIX（karlsen:），且不能还是占位符
if [ "${WALLET:0:${#ADDR_PREFIX}}" != "$ADDR_PREFIX" ]; then
    echo "[!] 钱包地址前缀应为 ${ADDR_PREFIX}，当前：$WALLET"
    echo "    Kaspa(kaspa:) 路线已被 lolMiner ${MINER_VERSION} 移除；请在 config.sh 填入 ${ADDR_PREFIX} 开头的真实地址。"
    exit 1
fi
case "$WALLET" in
    *PLACEHOLDER*) echo "[!] 钱包还是占位符未填：$WALLET —— 改 config.sh 的 WALLET_1/WALLET_2"; exit 1 ;;
esac

# ---------------- 组装 lolMiner 参数 ----------------
ARGS=( --algo "$ALGO" --worker "$WORKER" --pass "$MINER_PASS" )

# 矿池（lolMiner 多组 --pool/--user 即原生故障切换）
if is_on "$POOL_TLS"; then
    ARGS+=( --pool "$POOL_TLS" --user "$WALLET" )
fi
for p in $POOL_PRIMARY $POOL_BACKUPS; do
    if is_on "$p"; then
        ARGS+=( --pool "$p" --user "$WALLET" )
    fi
done

# 显卡选择（lolMiner --devices 逗号列表）
if is_on "$GPUS_N"; then
    ARGS+=( --devices "$GPUS_N" )
fi

# 满血超频（这些参数会被 linux 下的 NVML 应用，同样可交给 oc_tune.sh）
if is_on "$CORE_CLOCK_LOCK"; then ARGS+=( --cclk "$CORE_CLOCK_LOCK" ); fi
if is_on "$MEM_CLOCK_LOCK"; then
    ARGS+=( --mclk "$MEM_CLOCK_LOCK" )
elif is_on "$MEM_CLOCK_OFFSET"; then
    ARGS+=( --moff "$MEM_CLOCK_OFFSET" )
fi
if is_on "$POWER_LIMIT"; then ARGS+=( --pl "$POWER_LIMIT" ); fi
if is_on "$FAN_SPEED";   then ARGS+=( --fan "$FAN_SPEED" ); fi

# API / 温度保护 / 看门狗 / 统计
ARGS+=( --apiport "$API_PORT_N" )
if [ "$WATCHDOG_MODE" != "off" ] && [ -n "$WATCHDOG_MODE" ]; then
    ARGS+=( --watchdog "$WATCHDOG_MODE" )
    # script 模式：lolMiner 走 --watchdogscript 调外部脚本；旧版只传了 --watchdog script，
    # emergency.sh 从来没被接上（死代码）。这里补上接线，并确保脚本可执行。
    if [ "$WATCHDOG_MODE" = "script" ]; then
        if [ -f "$PACK_DIR/emergency.sh" ]; then
            [ -x "$PACK_DIR/emergency.sh" ] || chmod +x "$PACK_DIR/emergency.sh" 2>/dev/null || true
            ARGS+=( --watchdogscript "$PACK_DIR/emergency.sh" )
        else
            echo "[!] WATCHDOG_MODE=script 但找不到 $PACK_DIR/emergency.sh，回退 exit 模式"
            ARGS+=( --watchdog exit )
        fi
    fi
fi
if is_on "$T_STOP";  then ARGS+=( --tstop "$T_STOP" ); fi
if is_on "$T_START"; then ARGS+=( --tstart "$T_START" ); fi
if is_on "$STATS_FORMAT"; then ARGS+=( --statsformat "$STATS_FORMAT" ); fi
if is_on "$SILENCE"; then ARGS+=( --silence "$SILENCE" ); fi

# 干跑模式：只打印最终命令，不启动矿机（DRY_RUN=1 ./run_instance.sh 1 "*" 4066 test）
if [ "${DRY_RUN:-0}" = "1" ]; then
    exec 1>&3 2>&4   # 还原终端，让 DRY_RUN 输出直接可见
    echo "[DRY-RUN] $MINER_BIN ${ARGS[*]}"
    exit 0
fi

if [ ! -x "$MINER_BIN" ]; then
    echo "[!] 未找到矿机：$MINER_BIN"
    echo "    先运行：cd \"$PACK_DIR\" && ./download_miner.sh"
    echo "    下载失败多为网络问题：curl -I \"$MINER_URL\" 看能否通 GitHub。"
    exit 1
fi

{
    echo "==== $(date '+%F %T') 启动 ===="
    echo "钱包：   $WALLET"
    echo "矿工：   $WORKER"
    echo "显卡：   $GPUS_N"
    echo "矿池：   ${POOL_PRIMARY} （故障切换：${POOL_BACKUPS}）"
    echo "API：    http://127.0.0.1:${API_PORT_N}/gui"
    echo "命令：   $MINER_BIN ${ARGS[*]}"
    echo "======================="
} >> "$LOG"

FAST_FAILS=0
FAST_FAIL_WINDOW=20    # 单次运行小于此秒且非 watchdog 退出码，判定为快速失败
FAST_FAIL_LIMIT=3      # 连续如此多次后断然退出，避免参数错误死循环刷日志
while true; do
    set +e
    T0=$(date +%s)
    "$MINER_BIN" "${ARGS[@]}" >> "$LOG" 2>&1
    RC=$?
    T1=$(date +%s)
    set -e
    DUR=$((T1 - T0))
    if [ "$RC" = "42" ]; then
        FAST_FAILS=0   # watchdog 退出由 lolMiner 自身判定，继续重启
    elif [ "$DUR" -lt "$FAST_FAIL_WINDOW" ]; then
        FAST_FAILS=$((FAST_FAILS + 1))
        echo "[$(date '+%F %T')] 矿机退出 rc=${RC} 耗时 ${DUR}s（快速失败 #${FAST_FAILS}），${RESTART_DELAY}s 后重启" >> "$LOG"
        if [ "$FAST_FAILS" -ge "$FAST_FAIL_LIMIT" ]; then
            echo "[$(date '+%F %T')] 连续 ${FAST_FAIL_LIMIT} 次快速失败，断然退出（先检查参数/显卡/驱动）" >> "$LOG"
            exit 1
        fi
    else
        FAST_FAILS=0
        echo "[$(date '+%F %T')] 矿机退出 rc=${RC}，${RESTART_DELAY}s 后重启" >> "$LOG"
    fi
    sleep "$RESTART_DELAY"
done
